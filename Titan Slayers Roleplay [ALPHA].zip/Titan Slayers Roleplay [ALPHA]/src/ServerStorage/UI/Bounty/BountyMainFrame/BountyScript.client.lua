local Player = game.Players.LocalPlayer
local SampleWanted = script.Parent:WaitForChild('ScrollingFrame').one:Clone()

-- yScale interval +0.033
-- xScale 0.152
-- UDim2.new(0.152, 0, sum, 0)


function updateList()
	local FirstPos = -0.102
	script.Parent.ScrollingFrame:ClearAllChildren()
	for num,Player in ipairs(game.Players:GetPlayers()) do
		if Player:FindFirstChild('Bounty') and Player.Bounty.Value > 0 then
			local Clone = SampleWanted:Clone()
			Clone.Position = UDim2.new(0.152, 0, FirstPos, 0)
			FirstPos = FirstPos + 0.033
			Clone.Text = Player.Name
			Clone.TextLabel.Text = Player.Bounty.Value
			Clone.Parent = script.Parent.ScrollingFrame
		end
	end
end
updateList()

while wait(1) do
	updateList()
end