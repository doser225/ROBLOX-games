wait(1)

local TweenService = game:GetService('TweenService')

for num,Button in ipairs(script.Parent:WaitForChild('MainFrame'):GetChildren()) do
	if Button.ClassName == 'ImageButton' then
		local Entered = false
		local oldSize = Button.Size
		local oldPos = Button.Position
		Button.InputBegan:connect(function(InputObject)
			if InputObject.UserInputType == Enum.UserInputType.MouseMovement then
				Entered = true
				TweenService:Create(Button, TweenInfo.new(0.2, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), 
					{
						['Size'] = UDim2.new(oldSize.X.Scale, oldSize.X.Offset + 8, oldSize.Y.Scale, oldSize.Y.Offset + 8),
						['Position'] = UDim2.new(oldPos.X.Scale, oldPos.X.Offset - 4, oldPos.Y.Scale, oldPos.Y.Offset - 4)
					}
				):Play()
			end
			if InputObject.UserInputType == Enum.UserInputType.MouseButton1 then
				script.Parent.MainFrame.MainBackGround:ClearAllChildren()
				for num,Clone in ipairs(game.ReplicatedStorage.KeybindSections:FindFirstChild(Button.TextLabel.Text):GetChildren()) do
					local C = Clone:Clone()
					C.Parent = script.Parent.MainFrame.MainBackGround
				end
			end
		end)
		Button.InputEnded:connect(function(InputObject)
			if InputObject.UserInputType == Enum.UserInputType.MouseMovement then
				Entered = false
				TweenService:Create(Button, TweenInfo.new(0.2, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), 
					{
						['Size'] = oldSize,
						['Position'] = oldPos
					}
				):Play()
			end
		end)
	end
end