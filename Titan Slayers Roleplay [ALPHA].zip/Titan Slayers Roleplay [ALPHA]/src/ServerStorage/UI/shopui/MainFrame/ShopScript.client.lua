local Player = game.Players.LocalPlayer
local PlayerLvl = Player:WaitForChild('Level')

local BuyEvent = game.ReplicatedStorage:WaitForChild('MAINFE')
BuyEvent = BuyEvent:WaitForChild('ShopPurchase')

local info = script.Parent:WaitForChild('infobackground')
script.Parent:WaitForChild('shopbackground')
script.Parent.shopbackground:WaitForChild('shopinterior')
script.Parent.infobackground:WaitForChild('shoplock')
local Debris = game:GetService('Debris')

local MainFrame = script.Parent
local ShopName = script.Parent.shopbackground:WaitForChild('NPCNAME')
local Player = game.Players.LocalPlayer
local ShopValue = script.Parent:WaitForChild('ShopValue')

ShopName.Text = ShopValue.Value.Name

script.Parent.shopbackground:WaitForChild('YourGold').Text = 'Your Gold: ' .. Player:WaitForChild('Money').Value

Player:WaitForChild('Money').Changed:connect(function()
	script.Parent.shopbackground:WaitForChild('YourGold').Text = 'Your Gold: ' .. Player:WaitForChild('Money').Value
end)

script.Parent.shopbackground:WaitForChild('close').MouseButton1Click:connect(function()
	script.Parent.Parent.Enabled = false
	script.Parent.Parent:Destroy()
end)

local CogsIcon = script.Parent.shopbackground.shopinterior:WaitForChild('IconBox1')
CogsIcon.Parent = nil
local SwordIcon = script.Parent.shopbackground.shopinterior:WaitForChild('IconBox2')
SwordIcon.Parent = nil
local HeartIcon = script.Parent.shopbackground.shopinterior:WaitForChild('IconBox3')
HeartIcon.Parent = nil
local ShirtIcon = script.Parent.shopbackground.shopinterior:WaitForChild('IconBox4')
ShirtIcon.Parent = nil
local BackpackIcon = script.Parent.shopbackground.shopinterior:WaitForChild('IconBox5')
BackpackIcon.Parent = nil

local InfoBox = script.Parent.shopbackground.shopinterior:WaitForChild('InfoBox1')
InfoBox.Parent = nil

-- purchase noise 131323304
-- fail noise is 550209561

function determineItemType(num, ItemType)
	local Icon = nil
	if ItemType == 'ODMUpgrade' then
		Icon = CogsIcon:Clone()
	elseif ItemType == 'SwordUpgrade' then
		Icon = SwordIcon:Clone()
	elseif ItemType == 'HealthBoost' then
		Icon = HeartIcon:Clone()
	elseif ItemType == 'Clothing' then
		Icon = ShirtIcon:Clone()
	elseif ItemType == 'InventorySpace' then
		Icon = BackpackIcon:Clone()
	end
	Icon.Parent = script.Parent.shopbackground.shopinterior
	Icon.Position = UDim2.new(0.087, 0, 0.007 + ((num - 1) * 0.04), 0)
end

function loadItems()
	if ShopValue.Value ~= nil then
		for num,Item in ipairs(ShopValue.Value:GetChildren()) do
			local Clone = InfoBox:Clone()
			Clone.Parent = script.Parent.shopbackground.shopinterior
			Clone.Position = UDim2.new(0.175, 0, 0.007 + ((num - 1) * 0.04), 0)
			-- Icon xScale is 0.087
			Clone.ItemAndUpgrade.Text = Item.Name
			determineItemType(num, Item.ItemType.Value)
			Clone.Info.MouseButton1Click:connect(function()
				info.Parent = script.Parent
				script.Parent.infobackground.ItemCost.Text = 'Cost: ' .. Item.Cost.Value
				script.Parent.infobackground.LvlReq.Text = 'Level Req: ' .. Item.Level.Value
				script.Parent.infobackground.rectangle.descframe.itemdesc.Text = Item.Description.Value
				script.Parent.infobackground.ItemName.Text = Item.Name
				if PlayerLvl.Value >= Item.Level.Value then
					script.Parent.infobackground.shoplock.ImageTransparency = 1
				else
					script.Parent.infobackground.shoplock.ImageTransparency = 0
				end
			end)
			Clone.Buy.MouseButton1Click:connect(function()
				if BuyEvent:InvokeServer(Item) == true then
					local SuccessSound = Instance.new('Sound', game.Workspace)
					Debris:AddItem(SuccessSound, 2)
					SuccessSound.Volume = 1
					SuccessSound.SoundId = 'rbxassetid://131323304'
					SuccessSound:Play()
				else
					local SuccessSound = Instance.new('Sound', game.Workspace)
					Debris:AddItem(SuccessSound, 2)
					SuccessSound.Volume = 1
					SuccessSound.SoundId = 'rbxassetid://550209561'
					SuccessSound:Play()
				end
			end)
		end
	end
end
info.Parent = nil

loadItems()