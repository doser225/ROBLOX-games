local Main = script.Parent
game.ReplicatedStorage:WaitForChild('MAINFE')
local TeamSelect = game.ReplicatedStorage.MAINFE:WaitForChild('TeamSelection')

for num,Section in ipairs(Main:GetChildren()) do
	if Section.ClassName == 'Folder' then
		Section.Enlist.MouseButton1Click:connect(function()
			local EnlistButton = Section.Enlist
			TeamSelect:FireServer(EnlistButton.Parent.Name)
		end)
	end
end