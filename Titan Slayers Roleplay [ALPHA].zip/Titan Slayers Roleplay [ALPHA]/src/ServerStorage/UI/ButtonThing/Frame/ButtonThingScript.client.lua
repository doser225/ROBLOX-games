TweenService = game:GetService('TweenService')

local OCButton = script.Parent:WaitForChild('Close')
local HorseButton = script.Parent.Thing6
local MusicButton = script.Parent.Thing5
local HoodButton = script.Parent.Thing4
local FlashlightButton = script.Parent.Thing3
local LoreButton = script.Parent.Thing2
local ControlsButton = script.Parent.Thing1

local TeamSelectButton = script.Parent.Thing7

local Open = true
local OpenDB = true

OCButton.InputBegan:connect(function(Input)
	if Input.UserInputType == Enum.UserInputType.MouseButton1 and Open == true and OpenDB == true then
		OpenDB = false
		Open = false
		local Tween = TweenService:Create(script.Parent, TweenInfo.new(0.7, Enum.EasingStyle.Sine, Enum.EasingDirection.In), {['Position'] = UDim2.new(0,-600,0.775,0)})
		Tween:Play()
		local Tween = TweenService:Create(OCButton, TweenInfo.new(0.7, Enum.EasingStyle.Linear, Enum.EasingDirection.In), {['Rotation'] = -180})
		Tween:Play()
		Tween.Completed:Wait()
		OpenDB = true
	elseif Input.UserInputType == Enum.UserInputType.MouseButton1 and Open == false and OpenDB == true then
		OpenDB = false
		Open = true
		local Tween = TweenService:Create(script.Parent, TweenInfo.new(0.7, Enum.EasingStyle.Sine, Enum.EasingDirection.In), {['Position'] = UDim2.new(0,0,0.775,0)})
		Tween:Play()
		local Tween = TweenService:Create(OCButton, TweenInfo.new(0.7, Enum.EasingStyle.Linear, Enum.EasingDirection.In), {['Rotation'] = 0})
		Tween:Play()
		Tween.Completed:Wait()
		OpenDB = true
	end
end)

MusicEnabled = true

MusicButton.InputBegan:connect(function(Input)
	if Input.UserInputType == Enum.UserInputType.MouseButton1 and MusicEnabled == true then
		MusicEnabled = false
		MusicButton.Frame.BackgroundTransparency = 1
		if game.Workspace:FindFirstChild('AmbientNight') then
			game.Workspace.AmbientNight.Volume = 1
		end
		if game.Workspace:FindFirstChild('Music') then
			game.Workspace.Music.Volume = 1
		end
		if game.Workspace:FindFirstChild('AmbientDay') then
			game.Workspace.AmbientDay.Volume = 1
		end
	elseif Input.UserInputType == Enum.UserInputType.MouseButton1 and MusicEnabled == false then
		MusicEnabled = true
		MusicButton.Frame.BackgroundTransparency = 0
		if game.Workspace:FindFirstChild('AmbientNight') then
			game.Workspace.AmbientNight.Volume = 0
		end
		if game.Workspace:FindFirstChild('Music') then
			game.Workspace.Music.Volume = 0
		end
		if game.Workspace:FindFirstChild('AmbientDay') then
			game.Workspace.AmbientDay.Volume = 0
		end
	end
end)

local HoodEnable = game.ReplicatedStorage:WaitForChild('MAINFE'):WaitForChild('HoodEquip')

HoodButton.InputBegan:connect(function(Input)
	if Input.UserInputType == Enum.UserInputType.MouseButton1 then
		HoodEnable:InvokeServer()
	end
end)

local LightEnable = game.ReplicatedStorage:WaitForChild('MAINFE'):WaitForChild('LightEquip')

FlashlightButton.InputBegan:connect(function(Input)
	if Input.UserInputType == Enum.UserInputType.MouseButton1 then
		LightEnable:InvokeServer()
	end
end)

HorseButton.InputBegan:connect(function(Input)
	if Input.UserInputType == Enum.UserInputType.MouseButton1 then
		game.ReplicatedStorage.HorseFE.HorseCall:InvokeServer()
	end
end)

LoreButton.InputBegan:Connect(function(Input)
	if Input.UserInputType == Enum.UserInputType.MouseButton1 then
		if game.Players.LocalPlayer.PlayerGui:FindFirstChild('PlayerInventory') then
			game.Players.LocalPlayer.PlayerGui:FindFirstChild('PlayerInventory').Enabled = not game.Players.LocalPlayer.PlayerGui:FindFirstChild('PlayerInventory').Enabled
		end
		if game.Players.LocalPlayer.PlayerGui:FindFirstChild('stats') then
			game.Players.LocalPlayer.PlayerGui:FindFirstChild('stats').Enabled = not game.Players.LocalPlayer.PlayerGui:FindFirstChild('stats').Enabled
		end
	end
end)

ControlsButton.InputBegan:connect(function(Input)
	if Input.UserInputType == Enum.UserInputType.MouseButton1 then
		if game.Players.LocalPlayer.PlayerGui:FindFirstChild('Keybinding') then
			game.Players.LocalPlayer.PlayerGui:FindFirstChild('Keybinding').Enabled = not game.Players.LocalPlayer.PlayerGui:FindFirstChild('Keybinding').Enabled
		end
	end
end)

TeamSelectButton.InputBegan:connect(function(Input)
	if Input.UserInputType == Enum.UserInputType.MouseButton1 then
		if game.Players.LocalPlayer.PlayerGui:FindFirstChild('TeamSelection') then
			game.Players.LocalPlayer.PlayerGui:FindFirstChild('TeamSelection').Enabled = not game.Players.LocalPlayer.PlayerGui:FindFirstChild('TeamSelection').Enabled
		end
	end
end)