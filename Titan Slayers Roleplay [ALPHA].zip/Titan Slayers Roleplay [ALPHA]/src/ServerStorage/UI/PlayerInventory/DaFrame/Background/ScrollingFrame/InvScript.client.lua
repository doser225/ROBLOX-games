
local Player = game.Players.LocalPlayer

local ItemCopy = script.Parent:WaitForChild('ItemToCopy0')
ItemCopy.Parent = nil
Player:WaitForChild('Inventory')
Player.Inventory:WaitForChild('InventorySpace')
script.Parent.Parent:WaitForChild('PlayersName')
script.Parent.Parent.PlayersName.Text = ' Your Commodities ' .. #Player.Inventory:GetChildren()-1 .. '/' .. Player.Inventory.InventorySpace.Value

function updateInventory()
	for num,Item in ipairs(script.Parent:GetChildren()) do
		if Item.Name == 'ItemToCopy0' then
			Item:Destroy()
		end
	end
	script.Parent.Parent.PlayersName.Text = ' Your Commodities ' .. #Player.Inventory:GetChildren()-1 .. '/' .. Player.Inventory.InventorySpace.Value
	for num,Item in ipairs(Player.Inventory:GetChildren()) do
		if Item.ClassName ~= 'NumberValue' then
			local Clone = ItemCopy:Clone()
			Clone.Parent = script.Parent
			Clone.Position = UDim2.new(0.065, 0, (0.032 * (num - 2)) + 0.005, 0)
			Item:WaitForChild('Worth')
			Clone.worthimage.TextLabel.Text = Item.Worth.Value
			Clone.ItemName.Text = Item.Name
			print('Success item', Item.Name)
		end
	end
end

updateInventory()

Player.Inventory.ChildAdded:connect(updateInventory)
Player.Inventory.ChildRemoved:connect(updateInventory)

-- UDim2 Y scale 0.32
-- Starts at 0.005