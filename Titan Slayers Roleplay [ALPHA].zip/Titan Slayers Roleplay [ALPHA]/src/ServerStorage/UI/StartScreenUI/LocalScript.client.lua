game.Workspace:WaitForChild('MenuCamera')

--game.Workspace.CurrentCamera.CameraType = Enum.CameraType.Scriptable
--game.Workspace.CurrentCamera.CameraSubject = game.Workspace.MenuCamera
--[[game:GetService('RunService').Heartbeat:connect(function()
	game.Workspace.CurrentCamera.CFrame = game.Workspace.MenuCamera.CFrame * CFrame.Angles(0,math.rad(1),0)
end)]]

local TweenService = game:GetService('TweenService')

local PencilLine = script.Parent.LogoFrame.PencilLine

txt = 'A Six Spades Studios Game'

local UITween = TweenService:Create(script.Parent.LogoFrame, TweenInfo.new(2, Enum.EasingStyle.Linear, Enum.EasingDirection.InOut), {['Position'] = UDim2.new(0.01, 0, 0.05, 0)})
UITween:Play()
UITween.Completed:Wait()

local LineTween = TweenService:Create(PencilLine, TweenInfo.new(0.3, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {['Size'] = UDim2.new(0.01, 0, 0.9, 0)})
LineTween:Play()
LineTween.Completed:Wait()
--script.Parent.LogoFrame.StudioText.TextTransparency = 1
TransparencyTween = TweenService:Create(script.Parent.LogoFrame.StudioText, TweenInfo.new(#txt*0.02, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {['TextTransparency'] = 0})
TransparencyTween:Play()

for num = 1,#txt do
	script.Parent.LogoFrame.StudioText.Text = string.sub(txt, 1, num)
	wait(0.02)
end