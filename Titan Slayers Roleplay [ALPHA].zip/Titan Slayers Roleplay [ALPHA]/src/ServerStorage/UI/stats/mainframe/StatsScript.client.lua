local Player = game.Players.LocalPlayer

local TitanSlayed = Player:WaitForChild('TitanKills')
local BladeDura = Player:WaitForChild('ODMInfo'):WaitForChild('BladeDurability')
local BladeDamage = Player:WaitForChild('ODMInfo'):WaitForChild('BladeDamage')
local HookRange = Player:WaitForChild('ODMInfo'):WaitForChild('HookRange')
local GasAmount = Player:WaitForChild('Gas')

script.Parent.background.Titan.TitanNumber.Text = TitanSlayed.Value
script.Parent.background.damage.DamageNumber.Text = BladeDamage.Value
script.Parent.background.hook.HookNumber.Text = HookRange.Value
script.Parent.background.durability.DurabilityNumber.Text = BladeDura.Value
script.Parent.background.gas.GasNumber.Text = GasAmount.Value

TitanSlayed.Changed:connect(function()
	script.Parent.background.Titan.TitanNumber.Text = TitanSlayed.Value
end)

BladeDamage.Changed:connect(function()
	script.Parent.background.damage.DamageNumber.Text = BladeDamage.Value
end)

HookRange.Changed:connect(function()
	script.Parent.background.hook.HookNumber.Text = HookRange.Value
end)

BladeDura.Changed:connect(function()
	script.Parent.background.durability.DurabilityNumber.Text = BladeDura.Value
end)