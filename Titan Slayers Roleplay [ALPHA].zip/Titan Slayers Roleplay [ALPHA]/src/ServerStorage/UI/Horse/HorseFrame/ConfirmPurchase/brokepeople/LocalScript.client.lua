local Accept = script.Parent.No
local Decline = script.Parent.yes

local MAINFE = game.ReplicatedStorage:WaitForChild('MAINFE')
local HorsePurchase = MAINFE:WaitForChild('HorsePurchase')
script:WaitForChild('HorseName')

Accept.MouseButton1Click:Connect(function()
	HorsePurchase:InvokeServer(script.HorseName.Value)
	script.Parent:Destroy()
end)
Decline.MouseButton1Click:connect(function()
	game.Workspace.Camera.CameraType = Enum.CameraType.Custom
	script.Parent:Destroy()
end)