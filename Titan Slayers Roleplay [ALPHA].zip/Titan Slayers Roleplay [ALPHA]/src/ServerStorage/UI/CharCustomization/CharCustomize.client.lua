script.Parent.Enabled = false

script.Parent:WaitForChild('CharItems')
script.Parent:WaitForChild('Selectors')

local RunService = game:GetService('RunService')
local Mouse = game.Players.LocalPlayer:GetMouse()
local MAINFE = game.ReplicatedStorage:WaitForChild('MAINFE')
local OutfitAccept = MAINFE:WaitForChild('OutfitAccept')

local ShirtId = game.Players.LocalPlayer.CharData:WaitForChild('Shirt')
local PantsId = game.Players.LocalPlayer.CharData:WaitForChild('Pants')
local HatsId = game.Players.LocalPlayer.CharData:WaitForChild('Hair')
local EyesId = game.Players.LocalPlayer.CharData:WaitForChild('Eyes')
local MouthId = game.Players.LocalPlayer.CharData:WaitForChild('Mouth')

for num,Lobby in ipairs(game.Workspace:GetChildren()) do
	if Lobby.Name == 'CharCreate' and Lobby.ClassName == 'Folder' then
		Lobby:Destroy()
	end
end

local Player = game.Players.LocalPlayer
local TweenService = game:GetService('TweenService')

if game.Players.LocalPlayer:FindFirstChild('ShiftedBack') or game.Players.LocalPlayer:WaitForChild('SkipLoad').Value == true or game.Players.LocalPlayer:FindFirstChild('Arrested') then
	print("Destroying char customize!")
	if game.Players.LocalPlayer:FindFirstChild('Arrested') and Player.SkipLoad.Value == false then
		OutfitAccept:FireServer({ShirtId.Value, PantsId.Value, HatsId.Value, EyesId.Value, MouthId.Value})
		game.Players.LocalPlayer.Character:SetPrimaryPartCFrame(game.Workspace.PlayerSpawns.PrisonSpawns:GetChildren()[math.random(1, #game.Workspace.PlayerSpawns.PrisonSpawns:GetChildren())].CFrame)
	end
	game.Players.LocalPlayer.SkipLoad.Value = false
	script.Parent:Destroy()
	--[[if game.Players.LocalPlayer:FindFirstChild('ShiftedBack') then
		game.Players.LocalPlayer.ShiftedBack:Destroy()
	end]]
else
	Player.Character:WaitForChild('HumanoidRootPart')
	Player.Character:SetPrimaryPartCFrame(CFrame.new(8000,3000,8000))
	wait()
	Player.Character:WaitForChild('UpperTorso')
	Player.Character.UpperTorso.Anchored = true
	script.Parent.Enabled = true
	if string.match(game.Players.LocalPlayer.Character.Name, 'Titan') ~= nil then
		script.Parent:Destroy()
	end
	
	local CreationModel = game.ReplicatedStorage:WaitForChild('CharCreate'):Clone()
	CreationModel.Parent = game.Workspace
	local Avatar = CreationModel.AVATAR
	for num,Hat in ipairs(Avatar:GetChildren()) do
		if Hat.ClassName == "Accessory" or Hat.ClassName == 'Hat' then
			Hat:Destroy()
		end
	end
	
	if game.Workspace:FindFirstChild('Panel') then
		game.Workspace:FindFirstChild('Panel'):Destroy()
	end
	local falsePanel = Instance.new('Part', game.Workspace)
	falsePanel.Anchored = true
	falsePanel.Transparency = 1
	falsePanel.Size = Vector3.new(3,1.5,0.5)
	falsePanel.Name = "Panel"
	local neckCFrame = Avatar.Head.Neck.C0
	
	game.Workspace.CurrentCamera.CameraType = Enum.CameraType.Scriptable
	game.Workspace.CurrentCamera.CFrame = Avatar.UpperTorso.CFrame * CFrame.new(0,2.5,-4) * CFrame.Angles(math.rad(20),math.rad(180),0)
	falsePanel.CFrame = game.Workspace.CurrentCamera.CFrame * CFrame.new(0,0,-2)
	
	local MenuEffects = RunService.Heartbeat:connect(function()
		
		local panelRay = Ray.new(neckCFrame.p, Mouse.Hit.p)
		--local Part,Position = workspace:FindPartOnRay(panelRay)
		local lastPos = Mouse.Hit.p
		
		falsePanel.CFrame = game.Workspace.CurrentCamera.CFrame * CFrame.new(0,0,-2)
		if Mouse.Target == falsePanel then
			--Avatar.Head.Neck.C0 = Avatar.Head.Neck.Part0.CFrame:inverse() * CFrame.new((Avatar.Head.Neck.Part0.CFrame * Avatar.Head.Neck.C0.p), Mouse.Hit.p)
			Avatar.Head.Neck.C0 = Avatar.Head.Neck.Part0.CFrame:inverse() * CFrame.new((Avatar.Head.Neck.Part0.CFrame * Avatar.Head.Neck.C0.p), Mouse.Hit.p)
		end
		-- equation
		local XPos = Mouse.X / Mouse.ViewSizeX
		local YPos = Mouse.Y / Mouse.ViewSizeY
		local varX = 1 * XPos
		local varY = 1 * YPos
		-- THIS SECTION IS VERY IMPORTANT, YOU CAN USE IT LATER FOR ARM POINTS AND SUCH
		--game.Workspace.CurrentCamera.CFrame = Avatar.UpperTorso.CFrame * CFrame.new(0,3,-8) * CFrame.Angles(0--[[math.rad(30)]],math.rad(200),0)
		game.Workspace.CurrentCamera.CFrame = Avatar.UpperTorso.CFrame * CFrame.new(-1,0,-8) * CFrame.Angles(0--[[math.rad(30)]],math.rad(200),0)
		game.Workspace.CurrentCamera.CFrame = game.Workspace.CurrentCamera.CFrame * CFrame.new(varX - 0.5,-varY + 0.5,0)
	end)
	game.Players.LocalPlayer:WaitForChild('CharData')
	
	for num,CharSelection in ipairs({ShirtId.Value, PantsId.Value, HatsId.Value, EyesId.Value, MouthId.Value}) do
		if CharSelection.ClassName == 'Shirt' then
			for num,Item in ipairs(Avatar:GetChildren()) do
				if string.find(Item.Name, CharSelection.Name) then
					Item:Destroy()
				end
			end
			CharSelection:Clone().Parent = Avatar
		elseif CharSelection.ClassName == 'Pants' then
			for num,Item in ipairs(Avatar:GetChildren()) do
				if string.find(Item.Name, CharSelection.Name) then
					Item:Destroy()
				end
			end
			CharSelection:Clone().Parent = Avatar
		elseif CharSelection.ClassName == 'Decal' then
			for num,Item in ipairs(Avatar.Head:GetChildren()) do
				if string.find(Item.Name, CharSelection.Name) then
					Item:Destroy()
				end
			end
			CharSelection:Clone().Parent = Avatar.Head
		elseif CharSelection.ClassName == 'Accessory' or CharSelection.ClassName == 'Hat' then
			for num,Item in ipairs(Avatar:GetChildren()) do
				if string.find(Item.Name, CharSelection.Name) then
					Item:Destroy()
				end
			end
			local Clone = CharSelection:Clone()
			
			Clone.Parent = Avatar
			local Weld = Instance.new('ManualWeld', Clone.Handle)
			Weld.Part0 = Avatar.Head
			Weld.Part1 = Clone.Handle
			local c1, c2, c3, c4 = Clone.AttachmentPos, Clone.AttachmentForward, Clone.AttachmentRight, Clone.AttachmentUp
			Weld.C1 = CFrame.new(c1.X, c1.Y, c1.Z, c3.X, c3.Y, c3.Z, c4.X, c4.Y, c4.Z, -c2.X, -c2.Y, -c2.Z)
			Weld.C0 = Avatar.Head.HatAttachment.CFrame
		end
	end
	
	script.Parent:WaitForChild('PlayButton')
	script.Parent.PlayButton:WaitForChild('START')
	local PlayButton = script.Parent.PlayButton
	
	PlayButton.START.InputBegan:connect(function(InputObject)
		if InputObject.UserInputType == Enum.UserInputType.MouseButton1 and ShirtId.Value ~= nil and PantsId.Value ~= nil and MouthId.Value ~= nil and EyesId.Value ~= nil then
			CreationModel:Destroy()
			MenuEffects:Disconnect()
			game.Workspace.CurrentCamera.CameraType = Enum.CameraType.Custom
			game.Workspace.CurrentCamera.CameraSubject = game.Players.LocalPlayer.Character.Humanoid
			if game.Workspace:FindFirstChild('Panel') then
				game.Workspace:FindFirstChild('Panel'):Destroy()
			end
			OutfitAccept:FireServer({ShirtId.Value, PantsId.Value, HatsId.Value, EyesId.Value, MouthId.Value})
			script.Parent:Destroy()
		end
	end)
	if ShirtId.Value ~= nil and PantsId.Value ~= nil and MouthId.Value ~= nil and EyesId.Value ~= nil then
		PlayButton.Parent = script.Parent
	else
		PlayButton.Parent = nil
	end
	
	local CharItemsEnabled = false
	local CharSelection = nil
	local PageIndex = 1
	local PageItems = {}
	local CurrentSection = nil
	
	
	function updateUI(GuiObject)
		script.Parent.CharItems.BackGround.WhatPage.Text = 'Page ' .. PageIndex 
		if GuiObject.Name == 'Shirt' or GuiObject.Name == 'Pants' or GuiObject.Name == 'Hair' then
			for num = 1 + ((PageIndex - 1) * 9), 9 * PageIndex do
				pcall(function()
					local n = num%9
					if n == 0 then
						n = 9
					end
					script.Parent.CharItems.BackGround[n..'Item'].ItemValue.Value = nil
					script.Parent.CharItems.BackGround[n..'Item'].ItemImage.ImageTransparency = 1
					script.Parent.CharItems.BackGround[n..'Item'].ItemImage.Image = ''
					if game.ReplicatedStorage.Clothing[GuiObject.Name]:GetChildren()[num] ~= nil then
						table.insert(PageItems, game.ReplicatedStorage.Clothing[GuiObject.Name]:GetChildren()[num])
						--local bNum, eNum = string.find(game.ReplicatedStorage.Clothing[GuiObject.Name]:GetChildren()[num][GuiObject.Name..'Template'], '?id=')
						--print('rbxthumb://type=Asset&id='.. string.sub(game.ReplicatedStorage.Clothing[GuiObject.Name]:GetChildren()[num][GuiObject.Name..'Template'], eNum+1, string.len(game.ReplicatedStorage.Clothing[GuiObject.Name]:GetChildren()[num][GuiObject.Name..'Template'])) ..'&w=420&h=420')
						script.Parent.CharItems.BackGround[n..'Item'].ItemImage.ImageTransparency = 0
						--script.Parent.CharItems.BackGround[num..'Item'].ItemImage.Image = 'rbxthumb://type=Asset&id='.. string.sub(game.ReplicatedStorage.Clothing[GuiObject.Name]:GetChildren()[num][GuiObject.Name..'Template'], eNum+1) ..'&w=420&h=420'
						script.Parent.CharItems.BackGround[n..'Item'].ItemImage.Image = 'rbxthumb://type=Asset&id='.. game.ReplicatedStorage.Clothing[GuiObject.Name][GuiObject.Name .. num].Id.Value ..'&w=420&h=420'
						script.Parent.CharItems.BackGround[n..'Item'].ItemValue.Value = game.ReplicatedStorage.Clothing[GuiObject.Name][GuiObject.Name .. num]
					end
				end)
			end
		elseif GuiObject.Name == 'Eyes' or GuiObject.Name == 'Mouth' then
			for num = 1 + ((PageIndex - 1) * 9), 9 * PageIndex do
				pcall(function()
					local n = num%9
					if n == 0 then
						n = 9
					end
					script.Parent.CharItems.BackGround[n..'Item'].ItemValue.Value = nil
					script.Parent.CharItems.BackGround[n..'Item'].ItemImage.ImageTransparency = 1
					script.Parent.CharItems.BackGround[n..'Item'].ItemImage.Image = ''
					if game.ReplicatedStorage.Clothing[GuiObject.Name]:GetChildren()[num] ~= nil then
						table.insert(PageItems, game.ReplicatedStorage.Clothing[GuiObject.Name]:GetChildren()[num])
						script.Parent.CharItems.BackGround[n..'Item'].ItemImage.ImageTransparency = 0
						script.Parent.CharItems.BackGround[n..'Item'].ItemImage.Image = game.ReplicatedStorage.Clothing[GuiObject.Name][GuiObject.Name .. num].Texture
						script.Parent.CharItems.BackGround[n..'Item'].ItemValue.Value = game.ReplicatedStorage.Clothing[GuiObject.Name][GuiObject.Name .. num]
					end
				end)
			end
		end
	end
	
	for num,GuiObject in ipairs(script.Parent.CharItems.BackGround:GetChildren()) do
		if GuiObject.ClassName == 'ImageButton' and string.find(GuiObject.Name, 'Item') then
			local Entered = false
			GuiObject.ItemImage.MouseButton1Click:connect(function()
				print(GuiObject.ItemValue.Value:Clone())
				if CharSelection == 'Shirt' then
					ShirtId.Value = GuiObject.ItemValue.Value
					for num,Item in ipairs(Avatar:GetChildren()) do
						if string.find(Item.Name, CharSelection) then
							Item:Destroy()
						end
					end
					if GuiObject.ItemValue.Value ~= nil then
						GuiObject.ItemValue.Value:Clone().Parent = Avatar
					end
				elseif CharSelection == 'Mouth' then
					MouthId.Value = GuiObject.ItemValue.Value
					for num,Item in ipairs(Avatar.Head:GetChildren()) do
						if string.find(Item.Name, CharSelection) then
							Item:Destroy()
						end
					end
					GuiObject.ItemValue.Value:Clone().Parent = Avatar.Head
				elseif CharSelection == 'Pants' then
					PantsId.Value = GuiObject.ItemValue.Value
					for num,Item in ipairs(Avatar:GetChildren()) do
						if string.find(Item.Name, CharSelection) then
							Item:Destroy()
						end
					end
					if GuiObject.ItemValue.Value ~= nil then
						GuiObject.ItemValue.Value:Clone().Parent = Avatar	
					end
				elseif CharSelection == 'Eyes' then
					EyesId.Value = GuiObject.ItemValue.Value
					for num,Item in ipairs(Avatar.Head:GetChildren()) do
						if string.find(Item.Name, CharSelection) then
							Item:Destroy()
						end
					end
					if GuiObject.ItemValue.Value ~= nil then
						GuiObject.ItemValue.Value:Clone().Parent = Avatar.Head	
					end
				elseif CharSelection == 'Hair' then
					HatsId.Value = GuiObject.ItemValue.Value
					for num,Item in ipairs(Avatar:GetChildren()) do
						if string.find(Item.Name, CharSelection) then
							Item:Destroy()
						end
					end
					if GuiObject.ItemValue.Value ~= nil then
						local Clone = GuiObject.ItemValue.Value:Clone()
					
						Clone.Parent = Avatar
						local Weld = Instance.new('ManualWeld', Clone.Handle)
						Weld.Part0 = Avatar.Head
						Weld.Part1 = Clone.Handle
						local c1, c2, c3, c4 = Clone.AttachmentPos, Clone.AttachmentForward, Clone.AttachmentRight, Clone.AttachmentUp
						Weld.C1 = CFrame.new(c1.X, c1.Y, c1.Z, c3.X, c3.Y, c3.Z, c4.X, c4.Y, c4.Z, -c2.X, -c2.Y, -c2.Z)
						Weld.C0 = Avatar.Head.HatAttachment.CFrame
					end
				end
				if ShirtId.Value ~= nil and PantsId.Value ~= nil and MouthId.Value ~= nil and EyesId.Value ~= nil then
					PlayButton.Parent = script.Parent
				else
					PlayButton.Parent = nil
				end
			end)
			GuiObject.InputBegan:connect(function(InputObject)
				if InputObject.UserInputType == Enum.UserInputType.MouseMovement then
					Entered = true
					local Tween = TweenService:Create(GuiObject, TweenInfo.new(0.1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {['Size'] = UDim2.new(0,GuiObject.Size.X.Offset + 30,0,GuiObject.Size.Y.Offset + 30), ['Position'] = UDim2.new(GuiObject.Position.X.Scale,-15,GuiObject.Position.Y.Scale,-15)})
					Tween:Play()
				end
			end)
			GuiObject.InputEnded:connect(function(InputObject)
				if InputObject.UserInputType == Enum.UserInputType.MouseMovement then
					Entered = false
					local Tween = TweenService:Create(GuiObject, TweenInfo.new(0.1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {['Size'] = UDim2.new(0,121,0,146), ['Position'] = UDim2.new(GuiObject.Position.X.Scale,0,GuiObject.Position.Y.Scale,0)})
					Tween:Play()
				end
			end)
		elseif GuiObject.ClassName == 'ImageButton' and string.find(GuiObject.Name, 'Page') then
			GuiObject.InputBegan:connect(function(InputObject)
				if InputObject.UserInputType == Enum.UserInputType.MouseButton1 then
					if PageIndex > 1 and GuiObject.Name == 'PageLeft' then
						PageIndex = PageIndex - 1
						updateUI(CurrentSection)
					elseif PageIndex < 10 and GuiObject.Name == 'PageRight' then
						PageIndex = PageIndex + 1
						updateUI(CurrentSection)
					end
				end
			end)
		end
	end
	
	for num,GuiObject in ipairs(script.Parent.Selectors:GetChildren()) do
		local Entered = false
		if GuiObject.ClassName == 'ImageButton' then
			GuiObject.InputBegan:connect(function(InputObject)
				if InputObject.UserInputType == Enum.UserInputType.MouseMovement then
					Entered = true
					local Tween = TweenService:Create(GuiObject, TweenInfo.new(0.1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {['Size'] = UDim2.new(0,GuiObject.Size.X.Offset + 30,0,GuiObject.Size.Y.Offset + 10), ['Position'] = UDim2.new(GuiObject.Position.X.Scale,-15,GuiObject.Position.Y.Scale,-5)})
					Tween:Play()
				end
				if InputObject.UserInputType == Enum.UserInputType.MouseButton1 then
					--print('Clicked!')
					if CharItemsEnabled == false then
						CharItemsEnabled = true
						CharSelection = GuiObject.Name
						local Tween = TweenService:Create(script.Parent.CharItems, TweenInfo.new(0.25, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {['Position'] = UDim2.new(0.899,0,0.44,0)})
						Tween:Play()
						-- change ui v
						for num = 1,9 do
							script.Parent.CharItems.BackGround[num..'Item'].ItemImage.ImageTransparency = 1
							script.Parent.CharItems.BackGround[num..'Item'].ItemImage.Image = ''
						end
						script.Parent.CharItems.BackGround.WhatAreWeLookingAt.Text = GuiObject.Name
						PageIndex = 1
						CurrentSection = GuiObject
						updateUI(GuiObject)
						-- change ui ^
						
					elseif CharItemsEnabled == true and CharSelection ~= GuiObject.Name then
						CharSelection = GuiObject.Name
						local Tween = TweenService:Create(script.Parent.CharItems, TweenInfo.new(0.25, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {['Position'] = UDim2.new(1.5,0,0.44,0)})
						Tween:Play()
						Tween.Completed:Wait()
						
						-- change ui v
						-- rbxthumb://type=Asset&id=2045999635&w=420&h=420
						for num = 1,9 do
							script.Parent.CharItems.BackGround[num..'Item'].ItemImage.ImageTransparency = 1
							script.Parent.CharItems.BackGround[num..'Item'].ItemImage.Image = ''
						end
						script.Parent.CharItems.BackGround.WhatAreWeLookingAt.Text = GuiObject.Name
						PageIndex = 1
						CurrentSection = GuiObject
						updateUI(GuiObject)
						
						-- change ui ^
						
						local Tween = TweenService:Create(script.Parent.CharItems, TweenInfo.new(0.25, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {['Position'] = UDim2.new(0.899,0,0.44,0)})
						Tween:Play()
					end
				end
			end)
			GuiObject.InputEnded:connect(function(InputObject)
				if InputObject.UserInputType == Enum.UserInputType.MouseMovement then
					Entered = false
					local Tween = TweenService:Create(GuiObject, TweenInfo.new(0.1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {['Size'] = UDim2.new(0,179,0,59), ['Position'] = UDim2.new(GuiObject.Position.X.Scale,0,GuiObject.Position.Y.Scale,0)})
					Tween:Play()
				end
			end)
		end
	end
end