local Player = game.Players.LocalPlayer
local Faction = Player:WaitForChild('Faction')
local PlayerMoney = Player:WaitForChild('Money')
local Main = script.Parent
local Inventory = Player:WaitForChild('Inventory')

local EXP = Player:WaitForChild('EXP')
local Level = Player:WaitForChild('Level')
local Blades = Player.Character:WaitForChild('BladeSupply')
Main.Level.Text = 'Level ' .. Level.Value
Main.currentEXP.Size = UDim2.new(0,244 * (EXP.Value / (Level.Value * 1000)),0,16)

Level.Changed:connect(function()
	Main.Level.Text = 'Level ' .. Level.Value
end)

EXP.Changed:connect(function()
	Main.Level.Text = 'Level ' .. Level.Value
	Main.currentEXP.Size = UDim2.new(0,244 * (EXP.Value / (Level.Value * 1000)),0,16)
end)

if Blades.Name == 'BladeSupply' then
	local Blades = Player.Character:WaitForChild('BladeSupply')
	Main.BladesLeft.Text = 'Blades Left: ' .. Blades.Value
	Blades.Changed:connect(function()
		Main.BladesLeft.Text = 'Blades Left: ' .. Blades.Value
	end)
end

--[[script.Parent.PerksBool.Text = 'Inventory ' .. #Inventory:GetChildren() -1 .. '/5'

Inventory.ChildAdded:connect(function()
	script.Parent.PerksBool.Text = 'Inventory ' .. #Inventory:GetChildren() -1 .. '/5'
end)
Inventory.ChildRemoved:connect(function()
	script.Parent.PerksBool.Text = 'Inventory ' .. #Inventory:GetChildren() -1 .. '/5'
end)]]

script.Parent:WaitForChild('Branch')

script.Parent.Branch.Text = Faction.Value

Faction.Changed:connect(function()
	script.Parent.Branch.Text = Faction.Value
end)
Main.Bread.Text = "Cash: $" .. Player:FindFirstChild('Money').Value
PlayerMoney.Changed:connect(function()
	Main.Bread.Text = "Cash: $" .. Player:FindFirstChild('Money').Value
end)

Main:WaitForChild('circl')
content,isready = game.Players:GetUserThumbnailAsync(Player.UserId, Enum.ThumbnailType.HeadShot, Enum.ThumbnailSize.Size420x420)
Main.circl.ImageLabel.Image = content

Main:WaitForChild('BladeSeg')

local BladeChange = nil
local BladeSeg = Main.BladeSeg:Clone()
Main.BladeSeg:Destroy()

for num,Child in ipairs(Player.Character:GetChildren()) do
	if Child.Name == 'BladeDurability' then
		Main.Blades.Text = 'Blade Strength'
		Main.Blades.TextScaled = true
		for num = 1,math.ceil(Child.Value) do
			local Clone = BladeSeg:Clone()
			Clone.Parent = Main
			Clone.Position = UDim2.new(1.41, Offset, 1.43, 0)
			Offset = Offset + 42
		end
		BladeChange = Child.Changed:connect(function()
			local Offset = 0
			for num,Element in ipairs(Main:GetChildren()) do
				if Element.Name == 'BladeSeg' then
					Element:Destroy()
				end
			end
			for num = 1,math.ceil(Child.Value) do
				local Clone = BladeSeg:Clone()
				Clone.Parent = Main
				Clone.Position = UDim2.new(1.41, Offset, 1.43, 0)
				Offset = Offset + 42
			end
		end)
	end
end

Player.Character.ChildAdded:connect(function(Child)
	local Offset = 2
	if Child.Name == 'BladeDurability' then
		Main.Blades.Text = 'Blade Strength'
		Main.Blades.TextScaled = true
		for num = 1,math.ceil(Child.Value) do
			local Clone = BladeSeg:Clone()
			Clone.Parent = Main
			Clone.Position = UDim2.new(1.41, Offset, 1.43, 0)
			Offset = Offset + 42
		end
		BladeChange = Child.Changed:connect(function()
			local Offset = 0
			for num,Element in ipairs(Main:GetChildren()) do
				if Element.Name == 'BladeSeg' then
					Element:Destroy()
				end
			end
			for num = 1,math.ceil(Child.Value) do
				local Clone = BladeSeg:Clone()
				Clone.Parent = Main
				Clone.Position = UDim2.new(1.41, Offset, 1.43, 0)
				Offset = Offset + 42
			end
		end)
	end
end)

Player.Character.ChildRemoved:connect(function(Child)
	if Child.Name == 'BladeDurability' then
		if BladeChange ~= nil then
			BladeChange:Disconnect()
			for num,Element in ipairs(Main:GetChildren()) do
				if Element.Name == 'BladeSeg' then
					Element:Destroy()
				end
			end
		end
		Main.Blades.TextScaled = false
		Main.Blades.Text = 'N/A'
	end
end)