Player = game.Players.LocalPlayer
UIS = game:GetService('UserInputService')

Colors = {
	Color3.fromRGB(190, 49, 2),
	Color3.fromRGB(33, 33, 33),
	Color3.fromRGB(44, 122, 7)
}

if Player:FindFirstChild('FlareColor') == nil then
	Instance.new('Color3Value', Player).Name = 'FlareColor'
end

FlareColor = Player:WaitForChild('FlareColor')

local Index = 1
FlareColor.Value = Colors[Index]

for num,CurrentColor in ipairs(script.Parent:GetChildren()) do
	if CurrentColor.Name == 'Color' then
		CurrentColor.TextButton.Position = UDim2.new(CurrentColor.Position.X.Scale, 0, CurrentColor.Position.Y.Scale, 0)
		CurrentColor.TextButton.Size = UDim2.new(1, 0, 1, 0)
		CurrentColor.TextButton.BorderSizePixel = 0
		CurrentColor.TextButton.MouseButton1Down:connect(function()
			for num,CurrentColor in ipairs(script.Parent:GetChildren()) do
				if CurrentColor.Name == 'Color' then
					CurrentColor.TextButton.Position = UDim2.new(CurrentColor.Position.X.Scale, 0, CurrentColor.Position.Y.Scale, 0)
					CurrentColor.TextButton.Size = UDim2.new(1, 0, 1, 0)
					CurrentColor.TextButton.BorderSizePixel = 0
				end
			end
			FlareColor.Value = CurrentColor.TextButton.BackgroundColor3
			CurrentColor.TextButton.Position = UDim2.new(CurrentColor.Position.X.Scale, 3, CurrentColor.Position.Y.Scale, 3)
			CurrentColor.TextButton.Size = UDim2.new(1, -6, 1, -6)
			CurrentColor.TextButton.BorderSizePixel = 3
		end)
	end
end