wait(3)
Player = game.Players.LocalPlayer
local BlankObjective = script.Parent.BlankQuest.BlankObjective:Clone()
local Dsp = 0
for num,Folder in ipairs(Player:GetChildren()) do
	if Folder.ClassName == 'Folder' and string.find(Folder.Name, 'QUEST') then
		local Quest = script.Parent.BlankQuest:Clone()
		Quest.BlankObjective:Destroy()
		Quest.Parent = script.Parent.ImageLabel
		Quest.Name = 'Quest'
		Quest.Text = string.sub(Folder.Name, 0, string.len(Folder.Name) - 5)
		Quest.Size = UDim2.new(0,0,0,0)
		Quest:TweenSize(UDim2.new(0.6,0,0.18,0), Enum.EasingDirection.Out, Enum.EasingStyle.Elastic, 0.6)
		if Dsp ~= 0 then
			Quest.Position = UDim2.new(0.05,0,0.1,Dsp + 15)
		end
		for num,Objective in ipairs(Folder:GetChildren()) do
			local Obj = BlankObjective:Clone()
			Obj.Name = 'Objective'
			Obj.Parent = Quest
			Obj.Position = UDim2.new(0.1,50,0.8,(num-1)*15)
			Obj.Text = Objective.Name .. ' (' .. '0/' .. Objective.Value .. ')'
			Dsp = num*15
		end
	end
end