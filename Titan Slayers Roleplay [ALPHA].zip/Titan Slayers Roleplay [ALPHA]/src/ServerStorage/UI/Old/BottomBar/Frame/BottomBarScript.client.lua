local Player = game.Players.LocalPlayer
local TweenService = game:GetService('TweenService')

local HoodEquip = script.Parent:WaitForChild('HoodEquip')
local LightEquip = script.Parent:WaitForChild('LightEquip')

globalScale = 0

function setupButton(Button)
end

setupButton(HoodEquip)
setupButton(LightEquip)

local HoodEnable = game.ReplicatedStorage:WaitForChild('MAINFE'):WaitForChild('HoodEquip')

HoodEquip.InputBegan:Connect(function(InputObject)
	if InputObject.UserInputType == Enum.UserInputType.MouseMovement then
		TweenService:Create(HoodEquip, TweenInfo.new(0.1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {['Size'] = UDim2.new(1.2, 0, 1.2, 0), ['Position'] = UDim2.new(-0.1, 0, -0.1, 0)}):Play()
	end
end)
HoodEquip.InputEnded:Connect(function(InputObject)
	if InputObject.UserInputType == Enum.UserInputType.MouseMovement then
		TweenService:Create(HoodEquip, TweenInfo.new(0.1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {['Size'] = UDim2.new(1, 0, 1, 0), ['Position'] = UDim2.new(0, 0, 0, 0)}):Play()
	end
end)

HoodEquip.MouseButton1Click:Connect(function()
	HoodEnable:InvokeServer()
end)

local LightEnable = game.ReplicatedStorage:WaitForChild('MAINFE'):WaitForChild('LightEquip')

LightEquip.InputBegan:Connect(function(InputObject)
	if InputObject.UserInputType == Enum.UserInputType.MouseMovement then
		TweenService:Create(LightEquip, TweenInfo.new(0.1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {['Size'] = UDim2.new(1.2, 0, 1.2, 0), ['Position'] = UDim2.new(1.4, 0, -0.1, 0)}):Play()
		--LightEquip:TweenSizeAndPosition(UDim2.new(1.2, 0, 1.2, 0), UDim2.new(2, 0, -0.5, 0), Enum.EasingDirection.Out, Enum.EasingStyle.Bounce, 0.3)
		--[[wait(0.3)
		LightEquip.Size = UDim2.new(1.2, 0, 1.2, 0)
		LightEquip.Position = UDim2.new(2, 0, -0.5, 0)]]
	end
end)
LightEquip.InputEnded:Connect(function(InputObject)
	if InputObject.UserInputType == Enum.UserInputType.MouseMovement then
		TweenService:Create(LightEquip, TweenInfo.new(0.1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {['Size'] = UDim2.new(1, 0, 1, 0), ['Position'] = UDim2.new(1.5, 0, -0, 0)}):Play()
		--[[LightEquip:TweenSizeAndPosition(UDim2.new(1, 0, 1, 0), UDim2.new(1.5, 0, 0, 0), Enum.EasingDirection.Out, Enum.EasingStyle.Bounce, 0.3)
		wait(0.3)
		LightEquip.Size = UDim2.new(1, 0, 1, 0)
		LightEquip.Position = UDim2.new(1.5, 0, 0, 0)]]
	end
end)

LightEquip.MouseButton1Click:Connect(function()
	LightEnable:InvokeServer()
end)

