repeat
	wait(0.5)
until game.Players.LocalPlayer.Character

--[[repeat
	game.Workspace:FindFirstChild('CharCreate'):Destroy()
	wait()
until game.Workspace:FindFirstChild('CharCreate') == nil]]

if (game.Players.LocalPlayer:WaitForChild('SkipLoad').Value == true and game.Players.LocalPlayer.Character.Name == game.Players.LocalPlayer.Name) then
	game.Players.LocalPlayer.SkipLoad.Value = false
	print('ending script!')
	script.Parent:Destroy()
else
	for num,UI in ipairs(game.Players.LocalPlayer.PlayerGui:GetChildren()) do
		UI.Enabled = false
	end
	script.Parent.Enabled = true
	if string.match(game.Players.LocalPlayer.Character.Name, 'Titan') ~= nil then
		script.Parent:Destroy()
	end
	
	local CreationModel = game.Workspace:WaitForChild('CreationModel')
	local Avatar = CreationModel.AVATAR
	for num,Hat in ipairs(Avatar:GetChildren()) do
		if Hat.ClassName == "Accessory" or Hat.ClassName == 'Hat' then
			Hat:Destroy()
		end
	end
	ButtonBox = script.Parent:GetChildren()
	local RunService = game:GetService('RunService')
	local Mouse = game.Players.LocalPlayer:GetMouse()
	local MAINFE = game.ReplicatedStorage:WaitForChild('MAINFE')
	local OutfitAccept = MAINFE:WaitForChild('OutfitAccept')
	
	if game.Workspace:FindFirstChild('Panel') then
		game.Workspace:FindFirstChild('Panel'):Destroy()
	end
	local falsePanel = Instance.new('Part', game.Workspace)
	falsePanel.Anchored = true
	falsePanel.Transparency = 1
	falsePanel.Size = Vector3.new(3,1.5,0.5)
	falsePanel.Name = "Panel"
	local neckCFrame = Avatar.Head.Neck.C0
	
	
	wait(1)
	
	
	
	--game.Workspace.CurrentCamera.CameraSubject = Avatar.Humanoid
	
	game.Workspace.CurrentCamera.CameraType = Enum.CameraType.Scriptable
	game.Workspace.CurrentCamera.CFrame = Avatar.UpperTorso.CFrame * CFrame.new(0,2.5,-4) * CFrame.Angles(math.rad(20),math.rad(180),0)
	falsePanel.CFrame = game.Workspace.CurrentCamera.CFrame * CFrame.new(0,0,-2)
	
	local MenuEffects = RunService.Heartbeat:connect(function()
		
		local panelRay = Ray.new(neckCFrame.p, Mouse.Hit.p)
		--local Part,Position = workspace:FindPartOnRay(panelRay)
		local lastPos = Mouse.Hit.p
		
		falsePanel.CFrame = game.Workspace.CurrentCamera.CFrame * CFrame.new(0,0,-2)
		if Mouse.Target == falsePanel then
			--Avatar.Head.Neck.C0 = Avatar.Head.Neck.Part0.CFrame:inverse() * CFrame.new((Avatar.Head.Neck.Part0.CFrame * Avatar.Head.Neck.C0.p), Mouse.Hit.p)
			Avatar.Head.Neck.C0 = Avatar.Head.Neck.Part0.CFrame:inverse() * CFrame.new((Avatar.Head.Neck.Part0.CFrame * Avatar.Head.Neck.C0.p), Mouse.Hit.p)
		end
		-- equation
		local XPos = Mouse.X / Mouse.ViewSizeX
		local YPos = Mouse.Y / Mouse.ViewSizeY
		local varX = 1 * XPos
		local varY = 1 * YPos
		-- THIS SECTION IS VERY IMPORTANT, YOU CAN USE IT LATER FOR ARM POINTS AND SUCH
		--game.Workspace.CurrentCamera.CFrame = Avatar.UpperTorso.CFrame * CFrame.new(0,3,-8) * CFrame.Angles(0--[[math.rad(30)]],math.rad(200),0)
		game.Workspace.CurrentCamera.CFrame = Avatar.UpperTorso.CFrame * CFrame.new(-1,0,-8) * CFrame.Angles(0--[[math.rad(30)]],math.rad(200),0)
		game.Workspace.CurrentCamera.CFrame = game.Workspace.CurrentCamera.CFrame * CFrame.new(varX - 0.5,-varY + 0.5,0)
	end)
	game.Players.LocalPlayer:WaitForChild('CharData')
	local ShirtId = nil
	local PantsId = game.Players.LocalPlayer.CharData:WaitForChild('Hair')
	local HatsId = game.Players.LocalPlayer.CharData:WaitForChild('Hair')
	local FaceId = nil
	
	script.Parent.START.MouseButton1Click:connect(function()
		MenuEffects:Disconnect()
		game.Workspace.CurrentCamera.CameraType = Enum.CameraType.Custom
		game.Workspace.CurrentCamera.CameraSubject = game.Players.LocalPlayer.Character.Humanoid
		if game.Workspace:FindFirstChild('Panel') then
			game.Workspace:FindFirstChild('Panel'):Destroy()
		end
		print(HatsId, 'HATSID')
		OutfitAccept:FireServer({ShirtId, PantsId, HatsId, FaceId})
		script.Parent:Destroy()
	end)
	
	for num,Image in ipairs(ButtonBox) do
		if Image.ClassName == "ImageLabel" then
			local index = 1
			local clothesContainer = game.ReplicatedStorage.Clothing:FindFirstChild(Image.Name):GetChildren()
			-- place clothes on avatar based on index
			function identify(localIndex, Image)
				local clothesContainer = game.ReplicatedStorage.Clothing:FindFirstChild(Image.Name):GetChildren()
				if Image.Name == 'Hair' then
					for num,Hat in ipairs(Avatar:GetChildren()) do
						if Hat.ClassName == "Accessory" or Hat.ClassName == 'Hat' then
							Hat:Destroy()
						end
					end
					local Clone = clothesContainer[localIndex]:Clone()
					local Viewed = clothesContainer[localIndex]
					
					Clone.Parent = Avatar
					local Weld = Instance.new('ManualWeld', Clone.Handle)
					Weld.Part0 = Avatar.Head
					Weld.Part1 = Clone.Handle
					local c1, c2, c3, c4 = Clone.AttachmentPos, Clone.AttachmentForward, Clone.AttachmentRight, Clone.AttachmentUp
					Weld.C1 = CFrame.new(c1.X, c1.Y, c1.Z, c3.X, c3.Y, c3.Z, c4.X, c4.Y, c4.Z, -c2.X, -c2.Y, -c2.Z)
					Weld.C0 = Avatar.Head.HatAttachment.CFrame
					--Avatar.Humanoid:AddAccessory(Clone)
					--Clone.Handle.CFrame = Avatar.Head.CFrame
					HatsId = clothesContainer[localIndex]
					print(HatsId)
				elseif Image.Name == 'Shirt' then
					Avatar.Shirt.ShirtTemplate = clothesContainer[localIndex].ShirtTemplate
					ShirtId = clothesContainer[localIndex]
				elseif Image.Name == 'Pants' then
					Avatar.Pants.PantsTemplate = clothesContainer[localIndex].PantsTemplate
					PantsId = clothesContainer[localIndex]
				end
				print(HatsId)
			end
			identify(index, Image)
			Image.LB.MouseButton1Click:connect(function()
				if index == 1 then
					index = #clothesContainer
				else
					index = index - 1
				end
				identify(index, Image)
				--Image.Image = clothesContainer[index].ImageId.Value
			end)
			Image.RB.MouseButton1Click:connect(function()
				if index == #clothesContainer then
					index = 1
				else
					index = index + 1
				end
				identify(index, Image)
				--Image.Image = clothesContainer[index].ImageId.Value
			end)
		end
	end
end