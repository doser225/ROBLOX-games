local Accept = script.Parent.No
local Decline = script.Parent.yes

game.ReplicatedStorage:WaitForChild('MAINFE')

local Event = game.ReplicatedStorage.MAINFE:WaitForChild('SellAll')

Accept.MouseButton1Click:Connect(function()
	Event:FireServer()
	script.Parent:Destroy()
end)
Decline.MouseButton1Click:connect(function()
	game.Workspace.Camera.CameraType = Enum.CameraType.Custom
	script.Parent:Destroy()
end)