Player = game.Players.LocalPlayer
PMouse = Player:GetMouse()
Tool = script.Parent
ArrestMessage = script.Parent:WaitForChild('ArrestMessage')
ArrestEvent = game.ReplicatedStorage:WaitForChild('MAINFE'):WaitForChild('Arrest')
print("Arrest tool is active after definitions")
local Debounce = true
local Equipped = false

script.Parent.Equipped:connect(function()
	print("Tool equipped!")
	ArrestMessage.Parent = Player.PlayerGui
	Equipped = true
end)
script.Parent.Unequipped:connect(function()
	print("Tool unequipped!")
	ArrestMessage.Parent = nil
	Equipped = false
end)

PMouse.Button1Down:connect(function()
	print("Clicking")
	if Debounce == true and Equipped == true then
		Debounce = false
		print(PMouse.Target.Parent)
		for num,P in ipairs(game.Players:GetPlayers()) do
			if PMouse.Target:FindFirstAncestor(P.Name) then
				ArrestEvent:FireServer(PMouse.Target:FindFirstAncestor(P.Name))
			end
		end
		Debounce = true
	end
end)