wait(1)

Player = game:GetService('Players').LocalPlayer
UIS = game:GetService('UserInputService')
ShiftingFE = game.ReplicatedStorage:WaitForChild("ShiftingFE")
local ShiftDB = true
local Walking = Player.Character.Humanoid:LoadAnimation(script:WaitForChild("TitanWalk"))
local Jump = Player.Character.Humanoid:LoadAnimation(script:WaitForChild("Jump"))
local LeftPunch = Player.Character.Humanoid:LoadAnimation(script:WaitForChild("LeftPunch"))
local RightPunch = Player.Character.Humanoid:LoadAnimation(script:WaitForChild("RightPunch"))

local LeftKick = Player.Character.Humanoid:LoadAnimation(script:WaitForChild("LeftKick"))
local RightKick = Player.Character.Humanoid:LoadAnimation(script:WaitForChild("RightKick"))

local FightIdle = Player.Character.Humanoid:LoadAnimation(script:WaitForChild("FightIdle"))
local Shift = Player.Character.Humanoid:LoadAnimation(script:WaitForChild("Shift"))
local Jumping = false
local FightDB = true
W, A, S, D = false, false, false, false
WalkPlay = false
game.Workspace.CurrentCamera.CameraSubject = Player.Character.Humanoid
if Player.Character.Name == "Titan"..Player.UserId then
	Shifted = true
	Player.CameraMinZoomDistance = 25
	Player.CameraMaxZoomDistance = 70
	--FightIdle:Play()
else
	Shifted = false
end


Player.Character.Humanoid:GetPropertyChangedSignal("Jump"):connect(function()
	if Player.Character.Humanoid.Jump == true and Jumping == false and Shifted == true then
		Jump:Play()
		Jumping = true
	end
	if Player.Character.Humanoid.Jump == false and Jumping == true and Shifted == true then
		Jump:Stop()
		Jumping = false
		--FightIdle:Play()
	end
end)

UIS.InputBegan:connect(function(Key, Chatting)
	if Key.KeyCode == Enum.KeyCode.X and ShiftDB == true and Shifted == true and Chatting == false then
		ShiftDB = false
		ShiftingFE:FindFirstChild("ShiftBack"):FireServer()
		Shifted = false
		ShiftDB = true
	end
	if Key.KeyCode == Enum.KeyCode.K and ShiftDB == true and Shifted == false and Chatting == false then
		ShiftDB = false
		ShiftingFE:FindFirstChild("Shift"):FireServer()
		Shift:Play()
		wait(1)
		Player.Character.UpperTorso.Anchored = true
		Shifted = true
		ShiftDB = true
	end
	if Key.UserInputType == Enum.UserInputType.MouseButton1 and Shifted == true then
		if FightDB == true then
			FightDB = false
			if math.random(1,2) == 1 then
				LeftPunch:Play()
			else
				RightPunch:Play()
			end
			wait(0.8)
			FightDB = true
		end
	end
	if Key.KeyCode == Enum.KeyCode.Z and Chatting == false and Shifted == true then
		if FightDB == true then
			FightDB = false
			if math.random(1,2) == 1 then
				LeftKick:Play()
			else
				RightKick:Play()
			end
			wait(0.8)
			FightDB = true
		end
	end
	if Key.KeyCode == Enum.KeyCode.W and Chatting == false then
		W = true
	end
	if Key.KeyCode == Enum.KeyCode.A and Chatting == false then
		A = true
	end
	if Key.KeyCode == Enum.KeyCode.S and Chatting == false then
		S = true
	end
	if Key.KeyCode == Enum.KeyCode.D and Chatting == false then
		D = true
	end
	if (W or A or S or D) and Shifted == true then
		if WalkPlay == false then
			WalkPlay = true
			Walking:Play()
			--FightIdle:Play()
		end
	end
	if (W == true and A == true and S == true and D == true) and Shifted == true then
		if WalkPlay == true then
			WalkPlay = false
			Walking:Stop()
			--FightIdle:Stop()
		end
	end
	--print(Shifted)
end)

UIS.InputEnded:connect(function(Key, Chatting)
	if Key.KeyCode == Enum.KeyCode.W then
		W = false
	end
	if Key.KeyCode == Enum.KeyCode.A then
		A = false
	end
	if Key.KeyCode == Enum.KeyCode.S then
		S = false
	end
	if Key.KeyCode == Enum.KeyCode.D then
		D = false
	end
	if W == false and A == false and S == false and D == false then
		if WalkPlay == true then
			WalkPlay = false
			Walking:Stop()
		end
	end
end)