TweenService = game:GetService('TweenService')


function tweenBall(Part)
	if Part.ClassName == 'MeshPart' then
		Part.CFrame = Part.CFrame * CFrame.Angles(math.rad(1,360), math.rad(1,360), math.rad(1,360))
		local CircleInfo = TweenInfo.new(3, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)
		local Tween = TweenService:Create(Part, CircleInfo, {['Size'] = Vector3.new(30.2, 30.2, 0.5), ['Transparency'] = 1})
		Tween:Play()
	elseif Part.ClassName == 'Part' then
		Part.CFrame = Part.CFrame * CFrame.Angles(math.rad(1,360), math.rad(1,360), math.rad(1,360))
		local CircleInfo = TweenInfo.new(3, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)
		local Tween = TweenService:Create(Part, CircleInfo, {['Size'] = Vector3.new(Part.Size.X * 20, Part.Size.Y * 20, Part.Size.Z * 20), ['Transparency'] = 1})
		Tween:Play()	
	end
end

--script.Parent:SetPrimaryPartCFrame(script.Parent.PrimaryPart.CFrame * CFrame.Angles(math.rad(1,360), math.rad(1,360), math.rad(1,360)))
for num,Part in ipairs(script.Parent:GetChildren()) do
	if Part:IsA('BasePart') then
		tweenBall(Part)
	end
end
wait(0.4)
for num,Player in ipairs(game.Players:GetPlayers()) do
	pcall(function()
		if (Player.Character.HumanoidRootPart.Position - script.Parent.PrimaryPart.Position).magnitude < 30.2 then
			Player.Character.Humanoid:TakeDamage(math.random(30,40))
			Player.Character.Humanoid.PlatformStand = true
			wait(0.1)
			Player.Character.Humanoid.PlatformStand = false
		end
	end)
end

script.Parent.PrimaryPart.Sound:Play()
--script.Parent.PrimaryPart.Steam.Enabled = true
wait(script.Parent.PrimaryPart.Sound.TimeLength)
script.Parent:Destroy()