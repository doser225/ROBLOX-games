local Accept = script.Parent.Accept
local Decline = script.Parent.Decline

Accept.MouseButton1Click:Connect(function()
	
	
	
	script.Parent:Destroy()
end)
Decline.MouseButton1Click:connect(function()
	
	
	
	script.Parent:Destroy()
end)