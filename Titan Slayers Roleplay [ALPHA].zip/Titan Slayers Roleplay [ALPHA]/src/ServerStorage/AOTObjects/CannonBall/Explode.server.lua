local BT = script.Parent:WaitForChild('BodyThrust')
BT.Force = Vector3.new(1000,0,0)
local SingleExplode = true
game:GetService('Debris'):AddItem(script.Parent, 30)
local BF = Instance.new('BodyForce', script.Parent)
BF.Force = Vector3.new(0, (script.Parent:GetMass() * game.Workspace.Gravity) * 1, 0)
wait(0.5)
if BF ~= nil then
	BF.Force = Vector3.new(0, (script.Parent:GetMass() * game.Workspace.Gravity) * 0.8, 0)
end


--[[script.Parent.Touched:Connect(function(Part)
	if Part.Transparency < 1 and Part.CanCollide == true and SingleExplode == true then
		SingleExplode = false
		script.Parent.Anchored = true
		script.Parent.Transparency = 1
		--script.Parent.ParticleEmitter.Enabled = true
		local Explosion = Instance.new('Explosion', script.Parent)
		Explosion.Position = script.Parent.Position
		Explosion.BlastRadius = 0
		script.Parent.Sound:Play()
		wait(1)
		--script.Parent.ParticleEmitter.Enabled = false
		script.Parent:Destroy()
	end
end)]]