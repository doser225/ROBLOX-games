wait(1)
NPCHumanoid = script.Parent.Parent:WaitForChild('Humanoid')
script:WaitForChild('LanternHold')
local LanternHold = NPCHumanoid:LoadAnimation(script.LanternHold)

LanternHold:Play()
script:Destroy()