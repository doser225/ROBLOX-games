change = game.Players.LocalPlayer.Character.Humanoid:GetPropertyChangedSignal('SeatPart'):connect(function()
	if game.Players.LocalPlayer.Character.Humanoid.SeatPart == nil then
		script.Parent:Destroy()
		change:Disconnect()
	end
end)