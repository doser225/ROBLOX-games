TweenService = game:GetService('TweenService')


function tweenBall(Part)
	if Part.ClassName == 'MeshPart' then
		Part.CFrame = Part.CFrame * CFrame.Angles(math.rad(1,360), math.rad(1,360), math.rad(1,360))
		local CircleInfo = TweenInfo.new(3, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)
		local Tween = TweenService:Create(Part, CircleInfo, {['Size'] = Vector3.new(25.2, 25.2, 0.5), ['Transparency'] = 1})
		Tween:Play()
	elseif Part.ClassName == 'Part' then
		Part.CFrame = Part.CFrame * CFrame.Angles(math.rad(1,360), math.rad(1,360), math.rad(1,360))
		local CircleInfo = TweenInfo.new(3, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)
		local Tween = TweenService:Create(Part, CircleInfo, {['Size'] = Vector3.new(20.2, 20.2, 20.2), ['Transparency'] = 1})
		Tween:Play()	
	end
end
wait(3)
script.Parent:SetPrimaryPartCFrame(script.Parent.PrimaryPart.CFrame * CFrame.Angles(math.rad(1,360), math.rad(1,360), math.rad(1,360)))
for num,Part in ipairs(script.Parent:GetChildren()) do
	if Part:IsA('BasePart') then
		tweenBall(Part)
	end
end

script.Parent.PrimaryPart.Sound:Play()
--script.Parent.PrimaryPart.Steam.Enabled = true
wait(script.Parent.PrimaryPart.Sound.TimeLength)
script.Parent:Destroy()