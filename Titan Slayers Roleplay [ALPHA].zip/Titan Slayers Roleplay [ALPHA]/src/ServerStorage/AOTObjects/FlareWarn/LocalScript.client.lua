wait(5)
script.Parent:Destroy()