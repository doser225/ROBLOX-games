local BT = script.Parent:WaitForChild('BodyThrust')
BT.Force = Vector3.new(0,0,1000)
local SingleExplode = true
game:GetService('Debris'):AddItem(script.Parent, 60)


--[[script.Parent.Touched:Connect(function(Part)
	if Part.Transparency < 1 and Part.CanCollide == true and SingleExplode == true then
		SingleExplode = false
		script.Parent.Anchored = true
		script.Parent.Transparency = 1
		--script.Parent.ParticleEmitter.Enabled = true
		local Explosion = Instance.new('Explosion', script.Parent)
		Explosion.Position = script.Parent.Position
		Explosion.BlastRadius = 0
		script.Parent.Sound:Play()
		wait(1)
		--script.Parent.ParticleEmitter.Enabled = false
		script.Parent:Destroy()
	end
end)]]