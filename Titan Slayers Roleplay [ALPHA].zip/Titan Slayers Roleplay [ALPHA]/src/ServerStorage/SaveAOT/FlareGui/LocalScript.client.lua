Player = game.Players.LocalPlayer
UIS = game:GetService('UserInputService')

Colors = {
	Color3.fromRGB(190, 49, 2),
	Color3.fromRGB(33, 33, 33),
	Color3.fromRGB(44, 122, 7)
}

if Player:FindFirstChild('FlareColor') == nil then
	Instance.new('Color3Value', Player).Name = 'FlareColor'
end

FlareColor = Player:WaitForChild('FlareColor')

script.Parent.Frame.TextLabel1.TextColor3 = FlareColor.Value
script.Parent.Frame.TextLabel2.TextColor3 = FlareColor.Value
script.Parent.Frame.Title.TextColor3 = FlareColor.Value
script.Parent.Frame.BackgroundColor3 = FlareColor.Value

FlareColor.Changed:connect(function()
	script.Parent.Frame.TextLabel1.TextColor3 = FlareColor.Value
	script.Parent.Frame.TextLabel2.TextColor3 = FlareColor.Value
	script.Parent.Frame.Title.TextColor3 = FlareColor.Value
	script.Parent.Frame.BackgroundColor3 = FlareColor.Value
end)

local Index = 1
FlareColor.Value = Colors[Index]

UIS.InputBegan:connect(function(Key, Chatting)
	if Key.KeyCode == Enum.KeyCode.LeftBracket then
		if Index > 1 then
			Index = Index - 1
		elseif Index <= 1 then
			Index = #Colors
		end
		FlareColor.Value = Colors[Index]
	elseif Key.KeyCode == Enum.KeyCode.RightBracket then
		if Index < #Colors then
			Index = Index + 1
		elseif Index >= #Colors then
			Index = 1
		end
		FlareColor.Value = Colors[Index]
	end
end)