local anim = script.Parent.Parent.Humanoid:LoadAnimation(script.Parent)
wait(3)
anim:Play()