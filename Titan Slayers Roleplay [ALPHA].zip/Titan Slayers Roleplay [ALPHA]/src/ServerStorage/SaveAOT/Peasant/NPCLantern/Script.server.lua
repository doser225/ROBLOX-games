wait(1)
NPCHumanoid = script.Parent.Parent:FindFirstChild('Humanoid')
local LanternHold = NPCHumanoid:LoadAnimation(script.LanternHold)

LanternHold:Play()
script:Destroy()