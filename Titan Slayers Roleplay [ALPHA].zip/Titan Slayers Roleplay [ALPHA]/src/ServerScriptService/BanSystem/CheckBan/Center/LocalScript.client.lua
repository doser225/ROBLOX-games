wait(10)
script.Parent:Destroy()