script.Parent.TextLabel.TextBox.TextButton.MouseButton1Click:connect(function()
	if game.ReplicatedStorage:FindFirstChild("PlayerBansFE") then
		game.ReplicatedStorage.PlayerBansFE.SubmitReason:FireServer(script.Parent.TextLabel.TextBox.Text, tostring(script.Parent.BannedId.Value))
		script.Parent:Destroy()
	end
end)