-- NPCS
	
	game.Workspace:WaitForChild('Pedestrians')
	
	totalPedestrians = 5
	
	spawn(function()
		while true do
			if #game.Workspace.Pedestrians:GetChildren() < totalPedestrians then
				for num = 1,totalPedestrians-#game.Workspace.Pedestrians:GetChildren() do
					if math.random(1,10) >= 8 then
						local Clone = game.ServerStorage.AOTObjects.Noble:Clone()
						if math.random(1,3) == 1 then
							local Wallet = Instance.new('NumberValue', Clone)
							Wallet.Name = 'Wallet'
							Wallet.Value = math.random(500, 1000)
						end
						Clone.Parent = game.Workspace.Pedestrians
						Clone:SetPrimaryPartCFrame(game.Workspace.PedestrianSpawns:GetChildren()[math.random(1, #game.Workspace.PedestrianSpawns:GetChildren())].CFrame)
					else
						local Clone = game.ServerStorage.AOTObjects.Peasant:Clone()
						if math.random(1,3) == 1 then
							local Wallet = Instance.new('NumberValue', Clone)
							Wallet.Name = 'Wallet'
							Wallet.Value = math.random(1, 200)
						end
						Clone.Parent = game.Workspace.Pedestrians
						Clone:SetPrimaryPartCFrame(game.Workspace.PedestrianSpawns:GetChildren()[math.random(1, #game.Workspace.PedestrianSpawns:GetChildren())].CFrame)
					end
				end
			end
			wait(60)
		end
	end)
	
	local function moveNPC(NPC, WalkAnim)
		if NPC:FindFirstChild('Humanoid') and NPC:FindFirstChild('StolenFrom') == nil then
			NPC.Humanoid:MoveTo(Vector3.new(NPC.HumanoidRootPart.Position.X + math.random(-5,5), NPC.HumanoidRootPart.Position.Y, NPC.HumanoidRootPart.Position.Z + math.random(-5,5)))
			spawn(function()
				NPC.Humanoid.MoveToFinished:Wait()
				for num,Anim in ipairs(NPC.Humanoid:GetPlayingAnimationTracks()) do
					--print(Anim.Name)
					if Anim.Name ~= 'LanternHold' then
						Anim:Stop()
						Anim:Destroy()
					end
				end
				if WalkAnim ~= nil then	
					WalkAnim:Stop()
				end
			end)
		elseif NPC:FindFirstChild('StolenFrom') then
			NPC.Humanoid:MoveTo(NPC.StolenFrom.Value.Character.PrimaryPart.Position)
			spawn(function()
				NPC.Humanoid.MoveToFinished:Wait()
				for num,Anim in ipairs(NPC.Humanoid:GetPlayingAnimationTracks()) do
					--print(Anim.Name)
					if Anim.Name ~= 'LanternHold' then
						Anim:Stop()
						Anim:Destroy()
					end
				end
				if WalkAnim ~= nil then	
					WalkAnim:Stop()
				end
			end)
		end
	end

	
	-- CLOUDS
	
	local Debris = game:GetService('Debris')
	local Lights = true
	spawn(function()
		while true do
			wait(math.random(1,5))
			if Lights == false then
				local Cloud = game.ServerStorage.AOTObjects.Cloud:Clone()
				Debris:AddItem(Cloud, 60)
				local AGForce = Instance.new('BodyForce', Cloud.PrimaryPart)
				local Mass = 0
				for num,Part in ipairs(Cloud:GetChildren()) do
					Mass = Mass + Part:GetMass()
				end
				AGForce.Force = Vector3.new(0,game.Workspace.Gravity * Mass,game.Workspace.Gravity * Mass * -(math.random(6,8)/100))
				spawn(function()
					wait(3)
					AGForce.Force = Vector3.new(0,game.Workspace.Gravity * Mass,0)
				end)
				Cloud.Parent = game.Workspace
				Cloud:SetPrimaryPartCFrame(game.Workspace.CloudSpawner.CFrame * CFrame.new(math.random(-game.Workspace.CloudSpawner.Size.X,game.Workspace.CloudSpawner.Size.X),0,0) * CFrame.Angles(0,math.rad(math.random(-360,360)),0))
			end
		end
	end)
	
	
	
	
	-- CLOUDS
	
	
	game.Workspace:WaitForChild('LightsFolder')
	
	function randomGlass()
		local minimum = math.floor(#game.Workspace.LightsFolder:GetChildren() * math.random(70, 85) / 100)
		for min = 1,minimum do
			local Glass = game.Workspace.LightsFolder:GetChildren()[math.random(1, #game.Workspace.LightsFolder:GetChildren())]
			if Glass.Name == 'Glass' and Glass.Material ~= Enum.Material.Neon and Glass.ClassName ~= 'ManualWeld' then
				Glass.Material = Enum.Material.Neon
				Glass.Color = colors2[math.random(1,#colors2)]
				local GlassLight = game.ServerStorage.AOTObjects.GlassLight:Clone()
				GlassLight.Color = colors[math.random(1,#colors)]
				GlassLight.Parent = Glass
			elseif Glass.Name == 'FlameLightPart' then
				Glass.FlameLight.Enabled = true
				Glass.FlameParticle.Enabled = true
			end
		end
		for num,NPC in ipairs(game.Workspace.Pedestrians:GetChildren()) do
			print('giving out lanterns')
			if NPC:FindFirstChild('NPCLantern') then
				NPC.NPCLantern:Destroy()
			end
			for num,Anim in ipairs(NPC.Humanoid:GetPlayingAnimationTracks()) do
				if Anim.Name == 'LanternHold' then
					Anim:Stop()
					Anim:Destroy()
				end
			end
		end
		for num,NPC in ipairs(game.Workspace.Pedestrians:GetChildren()) do
			local Clone = game.ServerStorage.AOTObjects.NPCLantern:Clone()
			Clone.Parent = NPC
			print(NPC, ' gets a lantern')
		end
		for num,Fire in ipairs(game.Workspace.LightsFolder:GetChildren()) do
			if Fire.Name == 'BigFlame' or Fire.Name == 'Flame' or Fire.Name == 'FlameLightPart' then
				if Fire:FindFirstChild('FlameLight') then
					Fire.FlameLight.Enabled = true
				end
				if Fire:FindFirstChild('FlameParticle') then
					Fire.FlameParticle.Enabled = true
				end
			end
		end
	end
		
	
	
	colors = {Color3.fromRGB(255, 214, 164), Color3.fromRGB(255, 202, 155), Color3.fromRGB(255, 212, 151), Color3.fromRGB(255, 198, 147), Color3.fromRGB(255, 201, 162)}
	
	colors2 = {Color3.new(118, 118, 118)}
	
	--[[local function allGlass()
		for num,Glass in ipairs(game.Workspace.LightsFolder:GetChildren()) do
			if Glass.Name == 'Glass' then
				Glass.Material = Enum.Material.Neon
				Glass.Color = colors2[math.random(1,#colors2)]
				local GlassLight = game.ServerStorage.AOTObjects.GlassLight:Clone()
				GlassLight.Color = colors[math.random(1,#colors)]
				GlassLight.Parent = Glass
			elseif Glass.Name == 'FlameLightPart' then
				Glass.FlameLight.Enabled = true
				Glass.FlameParticle.Enabled = true
			end
		end
	end]]
	
	function allOffGlass()
		for num,Glass in ipairs(game.Workspace.LightsFolder:GetChildren()) do
			wait(0.5)
			if Glass.Name == 'Glass' then
				Glass.Material = Enum.Material.Glass
				Glass.Color = Color3.new(0,0,0)
				if Glass:FindFirstChild('GlassLight') then
					Glass:FindFirstChild('GlassLight'):Destroy()
				end
			elseif Glass.Name == 'FlameLightPart' then
				Glass.FlameLight.Enabled = false
				Glass.FlameParticle.Enabled = false
			end
		end
		for num,NPC in ipairs(game.Workspace.Pedestrians:GetChildren()) do
			if NPC:FindFirstChild('NPCLantern') then
				NPC.NPCLantern:Destroy()
			end
			for num,Anim in ipairs(NPC.Humanoid:GetPlayingAnimationTracks()) do
				if Anim.Name == 'LanternHold' then
					Anim:Stop()
					Anim:Destroy()
				end
			end
		end
		for num,Fire in ipairs(game.Workspace.LightsFolder:GetChildren()) do
			if Fire.Name == 'BigFlame' or Fire.Name == 'Flame' or Fire.Name == 'FlameLightPart' then
				if Fire:FindFirstChild('FlameLight') then
					Fire.FlameLight.Enabled = false
				end
				if Fire:FindFirstChild('FlameParticle') then
					Fire.FlameParticle.Enabled = false
				end
			end
		end
	end
	
	game.Lighting.ClockTime = 12
	
	local AmbientDay = script:WaitForChild('AmbientDay')
	local AmbientNight = script:WaitForChild('AmbientNight')
	
	spawn(function()
		while true do
			wait(1)
			game.Lighting.ClockTime = game.Lighting.ClockTime + 0.01
			if game.Lighting.ClockTime >= 6.3 and game.Lighting.ClockTime < 17.7 and Lights == true then	
				allOffGlass()
				Lights = false
				AmbientDay.Parent = game.Workspace
				AmbientDay:Play()
				AmbientNight:Stop()
				AmbientNight.Parent = script
			elseif game.Lighting.ClockTime >= 23.5 then
				game.Lighting.ClockTime = 0
			elseif game.Lighting.ClockTime >= 17.7 and Lights == false then
				randomGlass()
				game.Workspace.CloudFolder:ClearAllChildren()
				Lights = true
				AmbientNight.Parent = game.Workspace
				AmbientNight:Play()
				AmbientDay:Stop()
				AmbientDay.Parent = script
			end
		end
	end)
	wait(10)
	for num,NPC in ipairs(game.Workspace.Pedestrians:GetChildren()) do
		local WalkAnim = NPC.Humanoid:LoadAnimation(script.NPCWalk)
		spawn(function()
			while true do
				wait(math.random(1,3))
				for num,Anim in ipairs(NPC.Humanoid:GetPlayingAnimationTracks()) do
					--print(Anim.Name)
					if Anim.Name ~= 'LanternHold' then
						Anim:Stop()
						Anim:Destroy()
					end
				end
				WalkAnim:Play()
				moveNPC(NPC, WalkAnim)
			end
		end)
	end
	--randomGlass()
	AmbientDay.Parent = game.Workspace
	AmbientDay:Play()
	AmbientNight:Stop()
	AmbientNight.Parent = script
