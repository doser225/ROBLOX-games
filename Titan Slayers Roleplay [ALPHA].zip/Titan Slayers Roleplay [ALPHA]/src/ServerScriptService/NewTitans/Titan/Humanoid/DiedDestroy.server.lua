script.Parent.Died:Connect(function()
	wait(15)
	script.Parent.Parent:Destroy()
end)