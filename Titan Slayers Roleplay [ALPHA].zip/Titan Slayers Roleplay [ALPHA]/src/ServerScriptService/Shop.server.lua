--!! Gamepasses TBD later, create the framework for buying items/upgrades in the shop


local ShopFolder = Instance.new('Folder', game.ReplicatedStorage)
ShopFolder.Name = 'ShopFolder'


