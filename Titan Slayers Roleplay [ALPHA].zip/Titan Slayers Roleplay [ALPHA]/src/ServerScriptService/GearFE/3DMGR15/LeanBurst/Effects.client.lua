TweenService = game:GetService('TweenService')
local Effects = TweenInfo.new(0.3, Enum.EasingStyle.Linear, Enum.EasingDirection.Out)


local ImageTween = TweenService:Create(script.Parent.ImageLabel, Effects, {['ImageTransparency'] = 1})
local BillTween = TweenService:Create(script.Parent, Effects, {['Size'] = UDim2.new(10,0,10,0)})


BillTween:Play()
ImageTween:Play()

wait(0.5)
script.Parent:Destroy()