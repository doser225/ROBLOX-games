
	--local BladeData = game:GetService('DataStoreService'):GetDataStore('BladeData')
	
	local Debris = game:GetService('Debris')
	
	local TweenService = game:GetService('TweenService')
	
	local ThunderSpearEnabled = true
	
	

	local DiedEvent = nil
	
	local EffectsFolder = Instance.new('Folder', game.Workspace)
	EffectsFolder.Name = 'EffectsFolder'
	
	local SkeletonMeshes = {
		['LeftFoot'] = 'http://www.roblox.com/asset/?id=546760033',
		['LeftHand'] = 'http://www.roblox.com/asset/?id=546760018',
		['LeftLowerArm'] = 'http://www.roblox.com/asset/?id=546760022',
		['LeftLowerLeg'] = 'http://www.roblox.com/asset/?id=546760036',
		['LeftUpperArm'] = 'http://www.roblox.com/asset/?id=546760025',
		['LeftUpperLeg'] = 'http://www.roblox.com/asset/?id=546760037',
		['LowerTorso'] = 'http://www.roblox.com/asset/?id=546760046',
		['RightFoot'] = 'http://www.roblox.com/asset/?id=546760040',
		['RightHand'] = 'http://www.roblox.com/asset/?id=546760027',
		['RightLowerArm'] = 'http://www.roblox.com/asset/?id=546760029',
		['RightLowerLeg'] = 'http://www.roblox.com/asset/?id=546760042',
		['RightUpperArm'] = 'http://www.roblox.com/asset/?id=546760030',
		['RightUpperLeg'] = 'http://www.roblox.com/asset/?id=546760045',
		['UpperTorso'] = 'http://www.roblox.com/asset/?id=546760032',
	}
	game.Teams:WaitForChild('Rogue')
	game.Players.PlayerAdded:connect(function(Player)
		Player.CharacterAdded:connect(function()
			wait(1)	
			local GearType = '3DMG' -- 3DMG/APG
			if Player.TeamColor == game.Teams.Rogue.TeamColor then
				GearType = 'APG'
			end
			local Grabbed = Instance.new('BoolValue', Player.Character)
			Grabbed.Name = "Grabbed"
			Grabbed.Value = false
			if GearType == '3DMG' and Player.Character:FindFirstChild('ODMLoaded') == nil and Player:FindFirstChild('Arrested') == nil then
				local ODMLoaded = Instance.new('BoolValue', Player.Character)
				ODMLoaded.Name = 'ODMLoaded'
				repeat 
					wait()
				until _G[Player.Name]
				local BladeSupply = Instance.new('NumberValue', Player.Character)
				BladeSupply.Value = _G[Player.Name]['BladeAmount']
				BladeSupply.Name = 'BladeSupply'
				Player.Character:WaitForChild('RightHand')
				Player.Character:WaitForChild('LeftHand')
				Player.Character:WaitForChild('LowerTorso')
				Player.Character:WaitForChild('UpperTorso')
				Player:WaitForChild('Backpack')
				script:WaitForChild('3DMGR15'):Clone().Parent = Player.Backpack
				Player.DevEnableMouseLock = false
				if Player.Character.Name ~= "Titan" .. Player.UserId then
					if ThunderSpearEnabled == true and Player.Character:FindFirstChild('ThunderSpear') == nil then
						local temp = Instance.new('BoolValue', Player.Character)
						temp.Name = 'ThunderSpear'
						Player.Character:WaitForChild('LeftLowerArm')
						Player.Character:WaitForChild('RightLowerArm')
						Player.Character:WaitForChild('LeftUpperArm')
						Player.Character:WaitForChild('RightUpperArm')
						wait(2.5)
						temp:Destroy()
						local ThunderSpear = game.ServerStorage.AOTObjects.ThunderSpear:Clone()
						ThunderSpear.Parent = Player.Character
						ThunderSpear.Spear.Name = 'RightThunderSpear'
						local Weld = Instance.new("Weld",Player.Character.RightUpperArm)
						Weld.Name = 'RightThunderWeld'
						Weld.Part0 = ThunderSpear.PrimaryPart
						Weld.Part1 = Player.Character.RightLowerArm
						Weld.C0 = ThunderSpear.PrimaryPart.CFrame
						Weld.C1 = Player.Character.RightLowerArm.CFrame
						local ThunderSpear = game.ServerStorage.AOTObjects.ThunderSpear:Clone()
						ThunderSpear.Parent = Player.Character
						ThunderSpear.Spear.Name = 'LeftThunderSpear'
						local Weld = Instance.new("Weld",Player.Character.LeftLowerArm)
						Weld.Name = 'LeftThunderWeld'
						Weld.Part0 = ThunderSpear.PrimaryPart
						Weld.Part1 = Player.Character.LeftLowerArm
						Weld.C0 = ThunderSpear.PrimaryPart.CFrame
						Weld.C1 = Player.Character.LeftLowerArm.CFrame
					end	
					for num,Section in ipairs(game.ServerStorage.AOTObjects.ManeuverGearR15:GetChildren()) do
						if Section.Name ~= "Blade" and Section.ClassName == "Model" then
							local Clone = Section:Clone()
							local Weld = Instance.new("Weld")
							Weld.Part0 = Clone.PrimaryPart
							if Section.Name == "GasPiece" then
								Weld.Part1 = Player.Character.UpperTorso
							elseif Section.Name == "RArm" then
								Weld.Part1 = Player.Character["RightHand"]
							elseif Section.Name == "LArm" then
								Weld.Part1 = Player.Character["LeftHand"]
							elseif Section.Name == "TorsoSec" then
								Weld.Part1 = Player.Character["LowerTorso"]
							end	
							Weld.C0 = CFrame.new(0, 0, 0)
							Clone.Parent = Player.Character
							Weld.Parent = Weld.Part1
						end
					end
					Player.Character.GasPiece.GasPart.RodConstraint1.Attachment1 = Player.Character.TorsoSec.RBladeHold.Base.Attachment1
					Player.Character.GasPiece.GasPart.RodConstraint.Attachment1 = Player.Character.TorsoSec.LBladeHold.Base.Attachment1
					Player.Character.GasPiece.GasPart.RopeConstraint.Attachment1 = Player.Character.RArm.MeshPart.Attachment1
					Player.Character.GasPiece.GasPart.RopeConstraint1.Attachment1 = Player.Character.LArm.MeshPart.Attachment1
					local Clone = game.ServerStorage.UI.FlareColour:Clone()
					Clone.Parent = Player.PlayerGui
					--game.ServerStorage.ManeuverGear["3DMG"]:Clone().Parent = Player.Backpack
				end
			elseif GearType == 'APG' and Player:FindFirstChild('Arrested') == nil then
				if Player.Character.Name ~= "Titan" .. Player.UserId and Player.Character:FindFirstChild('APGLoaded') == nil then
					local APGLoaded = Instance.new('BoolValue', Player.Character)
					APGLoaded.Name = 'APGLoaded'
					Player.Character:WaitForChild('RightHand')
					Player.Character:WaitForChild('LeftHand')
					Player.Character:WaitForChild('LowerTorso')
					Player.Character:WaitForChild('UpperTorso')
					Player.Character:WaitForChild('LeftLowerArm')
					Player.Character:WaitForChild('RightLowerArm')
					Player.Character:WaitForChild('LeftUpperLeg')
					Player.Character:WaitForChild('RightUpperLeg')
					Player.Character:WaitForChild('LeftUpperArm')
					Player.Character:WaitForChild('RightUpperArm')
					Player:WaitForChild('Backpack')
					for num,Section in ipairs(game.ServerStorage.AOTObjects.APGear:GetChildren()) do
						if Player.Character:FindFirstChild(Section.Name) then
							local Clone = Section:Clone()
							Clone.Name = Clone.Name .. 'AP'
							Section.PrimaryPart.Transparency = 1
							local Weld = Instance.new("Weld")
							Weld.Part0 = Clone.PrimaryPart
							Weld.Part1 = Player.Character:FindFirstChild(Section.Name)
							Weld.C0 = CFrame.new(0, 0, 0)
							Clone.Parent = Player.Character
							Weld.Parent = Weld.Part1
						end
					end
					Player.DevEnableMouseLock = false
					script:WaitForChild('APGear'):Clone().Parent = Player.Backpack
					Player.Character.LeftLowerArmAP.RopePiece.RopeConstraint.Attachment0 = Player.Character.LeftLowerArmAP.RopePiece.Attachment0
					Player.Character.LeftLowerArmAP.RopePiece.RopeConstraint.Attachment1 = Player.Character.LeftUpperArmAP.RopePiece.Attachment1
					Player.Character.RightLowerArmAP.RopePiece.RopeConstraint.Attachment0 = Player.Character.RightLowerArmAP.RopePiece.Attachment0
					Player.Character.RightLowerArmAP.RopePiece.RopeConstraint.Attachment1 = Player.Character.RightUpperArmAP.RopePiece.Attachment1
				end
			end
			
			DiedEvent = Player.Character:WaitForChild('Humanoid').Died:connect(function()
				if workspace:FindFirstChild("GrappleFolder") then
					for num,SERVERWIRE in ipairs(workspace:FindFirstChild("GrappleFolder"):GetChildren()) do
						if SERVERWIRE.Name == "SERVERWIRE"..Player.Name.."Q" or SERVERWIRE.Name == "SERVERWIRE"..Player.Name.."E" then
							SERVERWIRE:Destroy()
						end
					end
				end
				DiedEvent:Disconnect()
			end)
		end)
	end)
		
	if workspace:FindFirstChild('GrappleFolder') then
		workspace.GrappleFolder.ChildAdded:connect(function(Child)
			local Count = 0
			for num,SERVERWIRE in ipairs(workspace:FindFirstChild("GrappleFolder"):GetChildren()) do
				if SERVERWIRE.Name == Child.Name then
					Count = Count + 1
				end
			end
			if Count > 1 then
				Count = Count - 1
				for num = 1,Count do
					workspace.GrappleFolder:FindFirstChild(Child.Name):Destroy()
				end
			end
		end)
	end
	
	local Folder = Instance.new("Folder", game.ReplicatedStorage)
	Folder.Name = "3DMGFE"
	
	local ProjectileFolder = Instance.new("Folder", game.Workspace)
	ProjectileFolder.Name = "ProjectileFolder"
	
	local ShootThunder = Instance.new('RemoteEvent', Folder)
	ShootThunder.Name = 'ShootThunder'
	
	local ManeuverGear = game.ServerStorage:WaitForChild("ManeuverGear")
	
	local GrappleFolder = Instance.new("Folder", game.Workspace)
	GrappleFolder.Name = "GrappleFolder"
	
	-- AP Gear
	local ShootAPGun = Instance.new("RemoteEvent", Folder)
	ShootAPGun.Name = "ShootAPGun"
	
	local ReloadAPGun = Instance.new("RemoteEvent", Folder)
	ReloadAPGun.Name = "ReloadAPGun"
	-- AP Gear
	
	local ReloadBlades = Instance.new("RemoteEvent", Folder)
	ReloadBlades.Name = "ReloadBlades"
	
	local StopGas = Instance.new("RemoteEvent", Folder)
	StopGas.Name = "StopGas"
	
	local KillTitan = Instance.new("RemoteEvent", Folder)
	KillTitan.Name = "KillTitan"

	local SlashEnemy = Instance.new("RemoteEvent", Folder)
	SlashEnemy.Name = "SlashEnemy"
	
	local ServerGrapple = Instance.new("RemoteEvent", Folder)
	ServerGrapple.Name = "ServerGrapple"
	
	local BoostEffect = Instance.new("RemoteEvent", Folder)
	BoostEffect.Name = "BoostEffect"
	
	local BoostEffectStop = Instance.new("RemoteEvent", Folder)
	BoostEffectStop.Name = "BoostEffectStop"

	local APGunDamage = Instance.new("RemoteEvent", Folder)
	APGunDamage.Name = "APGunDamage"
	
	local FlareShoot = Instance.new("RemoteFunction", Folder)
	FlareShoot.Name = "FlareShoot"

	local ThunderSpearDamage = Instance.new("RemoteFunction", Folder)
	ThunderSpearDamage.Name = "ThunderSpearDamage"
	
	local ServerGrappleDestroy = Instance.new("RemoteEvent", workspace)
	ServerGrappleDestroy.Name = "ServerGrappleDestroy"

	local APBulletsFolder = Instance.new('Folder', workspace)
	APBulletsFolder.Name = "APBulletsFolder"

	function ThunderSpearDamage.OnServerInvoke(Player, Spear, SpearCFrame)
		if string.find(Spear.Name, Player.Name) ~= nil and Spear.Parent.Name == 'ProjectileFolder' then
			Spear:SetPrimaryPartCFrame(SpearCFrame)
			local ClosestTitan = nil
			for num,Titan in ipairs(game.Workspace:WaitForChild('TitanFolder'):GetChildren()) do
				if Player.Character:FindFirstChild('HumanoidRootPart') and Titan:FindFirstChild('HumanoidRootPart') then
					local TitanDistance = (Player.Character.HumanoidRootPart.Position - Titan.HumanoidRootPart.Position).magnitude
					if ClosestTitan == nil then
						ClosestTitan = Titan
					elseif ClosestTitan ~= nil and ClosestTitan:FindFirstChild('HumanoidRootPart') ~= nil and TitanDistance < (Player.Character.HumanoidRootPart.Position - ClosestTitan.HumanoidRootPart.Position).magnitude then
						ClosestTitan = Titan
					end
				end
			end
			if (ClosestTitan.NapeHolder.Nape.Position - Spear.PrimaryPart.Position).magnitude < 15 then
				ClosestTitan.Humanoid:TakeDamage(math.random(30,50))
				ClosestTitan.Head.TitanHealthUI.Frame.GreenBar.Size = UDim2.new(2.48 * ClosestTitan.Humanoid.Health/ClosestTitan.Humanoid.MaxHealth, 0, 0.31, 0)
			end
			if ClosestTitan.Humanoid.Health <= 0 then
				local Monster = ClosestTitan
				for num,Motor6D in ipairs(Monster:GetDescendants()) do
					if Motor6D:IsA('BasePart') and Motor6D.Name ~= 'Nape' and string.find(Motor6D.Name, 'WeakKnee') == nil then
						Motor6D.CanCollide = true
						Motor6D.Anchored = false
					end
					if Motor6D.ClassName == 'Motor6D' and Motor6D.Name ~= 'Neck' and string.find(Motor6D.Name, 'Wrist') == nil and string.find(Motor6D.Name, 'Ankle') == nil then
						local BallSocket = Instance.new('BallSocketConstraint', Motor6D.Parent)
						local motoName = Motor6D.Name
						local Attachment0 = Motor6D.Parent:FindFirstChild(motoName .. 'Attachment') or Motor6D.Parent:FindFirstChild(motoName .. 'RigAttachment')
						local Attachment1 = Motor6D.Part0:FindFirstChild(motoName .. 'Attachment') or Motor6D.Part0:FindFirstChild(motoName .. 'RigAttachment')
						if Attachment0 and Attachment1 then
							BallSocket.Attachment0 = Attachment0
							BallSocket.Attachment1 = Attachment1
							Motor6D:Destroy()
						end
						--Monster:SetPrimaryPartCFrame(Monster.PrimaryPart.CFrame * CFrame.Angles(math.rad(45),0,0))
					end
				end
				local oldPart = Monster
				Debris:AddItem(Monster, 15)
				Monster.NapeHolder:Destroy()
				oldPart.HumanoidRootPart:Destroy()
				oldPart.PrimaryPart = oldPart.Head
				if oldPart.Head:FindFirstChild('TitanHealthUI') then
					oldPart.Head.TitanHealthUI:Destroy()
				end
				oldPart.LWKHold:Destroy()
				oldPart.RWKHold:Destroy()
				oldPart.EyesHolder:Destroy()
				wait(5)
				for num,Steam in ipairs(oldPart:GetDescendants()) do
					if Steam.Name == 'Steam' and Steam.ClassName == 'ParticleEmitter' then
						Steam.Enabled = true
					end
				end
				wait(5)
				for num,Part in ipairs(oldPart:GetDescendants()) do
					if Part:IsA('BasePart') then
						Part.Color = Color3.fromRGB(0,0,0)
					end
				end
			end	
		end
		return nil
	end

	ReloadAPGun.OnServerEvent:connect(function(Player)
		if Player.Character.RightHandAP:FindFirstChild('Expended') and Player.Character.LeftHandAP:FindFirstChild('Expended') and #Player.Character.LeftUpperLegAP.Ammo:GetChildren() > 0 and #Player.Character.RightUpperLegAP.Ammo:GetChildren() > 0 then
			Player.Character.Humanoid:LoadAnimation(script.GunReload):Play()
			Player.Character.LeftHandAP.Expended.Transparency = 1
			Player.Character.RightHandAP.Expended.Transparency = 1
			local Clone = Player.Character.LeftHandAP.Expended:Clone()
			Debris:AddItem(Clone, 10)
			Clone.Parent = game.Workspace
			Clone.CFrame = Player.Character.LeftHandAP.Expended.CFrame
			Clone.Transparency = 0
			Clone:ClearAllChildren()
			Clone.CanCollide = true
			local Clone = Player.Character.RightHandAP.Expended:Clone()
			Debris:AddItem(Clone, 10)
			Clone.Parent = game.Workspace
			Clone.CFrame = Player.Character.RightHandAP.Expended.CFrame
			Clone.Transparency = 0
			Clone:ClearAllChildren()
			Clone.CanCollide = true
			wait(15/30)
			Player.Character.LeftHandAP.Expended.Transparency = 0
			Player.Character.LeftUpperLegAP.Ammo:GetChildren()[math.random(1,#Player.Character.LeftUpperLegAP.Ammo:GetChildren())]:Destroy()
			wait(6/30)
			Player.Character.RightUpperLegAP.Ammo:GetChildren()[math.random(1,#Player.Character.RightUpperLegAP.Ammo:GetChildren())]:Destroy()
			Player.Character.RightHandAP.Expended.Transparency = 0
			Player.Character.RightHandAP:FindFirstChild('Expended').Name = 'Canister'
			Player.Character.LeftHandAP:FindFirstChild('Expended').Name = 'Canister'
		end
	end)
	
	APGunDamage.OnServerEvent:connect(function(Player, PlayerTouch, Bullet)
		if (PlayerTouch.HumanoidRootPart.Position - Bullet.Position).magnitude < 46.2 and PlayerTouch.Name ~= Player.Name then
			Player.Bounty.Value = Player.Bounty.Value + 10
			PlayerTouch.Humanoid:TakeDamage(math.random(25,30))
		end
	end)

	ShootAPGun.OnServerEvent:connect(function(Player, MousePos, infoDictionary)
		if Player.Character.RightHandAP:FindFirstChild('Canister') then
			spawn(function()
				Player.Character.RightHandAP.Canister.CanisterParticle.Enabled = true
				Player.Character.RightHandAP.Canister.ShotSound:Play()
				wait(0.2)
				Player.Character.RightHandAP.Canister.CanisterParticle.Enabled = false
			end)
			
			for num = 1,6 do
				--local RandomRay = Ray.new(Player.Character.RightHandAP.Canister.Position, (Player.Character.RightHandAP.Canister.Position - MousePos.p))
				--local Part,Position,Normal = workspace:FindPartOnRay(RandomRay, Player.Character)
				local Bullet = game.ServerStorage.AOTObjects.APBullet:Clone()
				Debris:AddItem(Bullet, 15)
				Bullet.Name = Player.Name
				Bullet.Parent = APBulletsFolder
				Bullet:SetNetworkOwner(Player)
				Bullet:ClearAllChildren()
				Bullet.CFrame = infoDictionary[num]
				--local Tween = TweenService:Create(Bullet, TweenInfo.new(15, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {['CFrame'] = Bullet.CFrame * CFrame.new(800,0,0)})
				--Tween:Play()
			end
			pcall(function()
				spawn(function()
					Player.Character.RightHandAP.Canister.CanisterParticle.Enabled = true
					wait(0.2)
					Player.Character.RightHandAP.Canister.CanisterParticle.Enabled = false
				end)
			end)
			wait(0.3)
			if Player.Character.RightHandAP:FindFirstChild('Canister') then
				Player.Character.RightHandAP:FindFirstChild('Canister').Name = 'Expended'
			end
		elseif Player.Character.LeftHandAP:FindFirstChild('Canister') then
			spawn(function()
				Player.Character.LeftHandAP.Canister.CanisterParticle.Enabled = true
				Player.Character.LeftHandAP.Canister.ShotSound:Play()
				wait(0.2)
				Player.Character.LeftHandAP.Canister.CanisterParticle.Enabled = false
			end)
			
			for num = 1,6 do
				--local RandomRay = Ray.new(Player.Character.LeftHandAP.Canister.Position, (Player.Character.LeftHandAP.Canister.Position - MousePos.p))
				--local Part,Position,Normal = workspace:FindPartOnRay(RandomRay, Player.Character)
				local Bullet = game.ServerStorage.AOTObjects.APBullet:Clone()
				Debris:AddItem(Bullet, 15)
				Bullet.Name = Player.Name
				Bullet.Parent = APBulletsFolder
				Bullet:SetNetworkOwner(Player)
				Bullet:ClearAllChildren()
				Bullet.CFrame = infoDictionary[num]
				--local Tween = TweenService:Create(Bullet, TweenInfo.new(15, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {['CFrame'] = Bullet.CFrame * CFrame.new(800,0,0)})
				--Tween:Play()
			end
			pcall(function()
				spawn(function()
					Player.Character.LeftHandAP.Canister.CanisterParticle.Enabled = true
					wait(0.2)
					Player.Character.LeftHandAP.Canister.CanisterParticle.Enabled = false
				end)
			end)
			wait(0.3)
			if Player.Character.LeftHandAP:FindFirstChild('Canister') then
				Player.Character.LeftHandAP:FindFirstChild('Canister').Name = 'Expended'
			end
		end
	end)
	
	local function Flare(Player, FlareColor)
		local Anim = Player.Character.Humanoid:LoadAnimation(game.ServerStorage.AOTObjects.FlareAnim)
		Anim:Play()
		wait(0.4)
		local FlareGun = game.ServerStorage.AOTObjects.Flaregun:Clone()
		FlareGun.Parent = Player.Character
		local Weld = Instance.new('Weld', Player.Character['LeftLowerArm'])
		Weld.Part0 = FlareGun.PrimaryPart
		Weld.Part1 = Player.Character['LeftLowerArm']
		Weld.C0 = FlareGun.PrimaryPart.CFrame
		Weld.C1 = Player.Character['LeftLowerArm'].CFrame
		Debris:AddItem(Weld, 1.8)
		Debris:AddItem(FlareGun, 1.8)
		Player.Character.RArm.MeshPart.Transparency = 1
		wait(0.43)
		local FlareShot = game.ServerStorage.AOTObjects.FlareShot:Clone()
		FlareShot.Parent = game.Workspace
		if FlareColor then
			FlareShot.BillboardGui.ImageLabel.ImageColor3 = FlareColor
			FlareShot.Sparks.Color = ColorSequence.new(FlareColor)
			FlareShot.Smoke.Color = ColorSequence.new(FlareColor)
			FlareShot.Trail.Color = ColorSequence.new(FlareColor)
			FlareShot.PointLight.Color = FlareColor
		end
		FlareShot.CFrame = FlareGun.FlaregunModel.PrimaryPart.CFrame * CFrame.Angles(0,math.rad(90),0)
		Debris:AddItem(FlareShot, 10)
		--!! POSSIBLY REMOVE LINE 133 LATER
		--Debris:AddItem(FlareShoot.BodyForce, 4)
		FlareGun.FlaregunModel.Barrel.Sound:Play()
		wait(1)
		Player.Character.RArm.MeshPart.Transparency = 0
		Anim:Stop()
		return 'flare was shot'
	end
	
	FlareShoot.OnServerInvoke = Flare
	
	ShootThunder.OnServerEvent:connect(function(Player, Spear, Pos)
		if Pos ~= nil then
			Debris:AddItem(Spear, 10)
			if Spear.Name == 'RightThunderSpear' then
				Player.Character.Humanoid:LoadAnimation(script.RightThunder):Play()
			elseif Spear.Name == 'LeftThunderSpear' then
				Player.Character.Humanoid:LoadAnimation(script.LeftThunder):Play()	
			end
			Player.Character:SetPrimaryPartCFrame(CFrame.new(Player.Character.PrimaryPart.CFrame.p, Pos.p))
			local SpearParent = Instance.new('ObjectValue', Spear)
			SpearParent.Value = Spear.Parent
			SpearParent.Name = 'SpearParent'
			local SpearPos = Instance.new('CFrameValue', Spear)
			SpearPos.Value = Pos
			SpearPos.Name = 'Pos'
			local OriginPlayer = Instance.new('ObjectValue', Spear)
			OriginPlayer.Name = 'OP'
			OriginPlayer.Value = Player
			local OriginHolst = Instance.new('ObjectValue', Spear)
			OriginHolst.Name = 'OriginHolst'
			OriginHolst.Value = Spear.PrimaryPart.BodyToHolst.Part1
			if Spear.Name == 'RightThunderSpear' then
				wait(12/30)
				if Player.Character.RightUpperArm:FindFirstChild('RightThunderWeld') then
					Player.Character.RightUpperArm.RightThunderWeld:Destroy()
				end
			elseif Spear.Name == 'LeftThunderSpear' then
				wait(26/40)
				if Player.Character.LeftLowerArm:FindFirstChild('LeftThunderWeld') then
					Player.Character.LeftLowerArm.LeftThunderWeld:Destroy()
				end
			end
			Spear.Name = Player.Name .. 'Spear'
			for num,Part in ipairs(Spear:GetChildren()) do
				if Part:IsA('BasePart') then
					Part:SetNetworkOwner(Player)
				end
			end
			--Spear.PrimaryPart.CFrame.p - Pos.p).magnitude/100
			--[[local SpearTweenInfo = TweenInfo.new(1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out)
			local SpearTween = TweenService:Create(Spear.PrimaryPart, SpearTweenInfo, {['CFrame'] = CFrame.new(Spear.PrimaryPart.CFrame.p, Pos.p) * CFrame.Angles(0,math.rad(270),0) * CFrame.new(-(Spear.PrimaryPart.CFrame.p - Pos.p).magnitude + 1.5,0,0)})]]
			if Spear.Body:FindFirstChild('BodyToHolst') then
				Spear.Body.BodyToHolst:Destroy()
			end
			local ThunderSpear = Spear.Parent
			Spear.PrimaryPart.Anchored = true
			ThunderSpear.Name = 'SPENT'
			Spear.Parent = ProjectileFolder
			--[[print(Spear.PrimaryPart.Orientation)
			Spear.PrimaryPart.Anchored = true
			Spear:SetPrimaryPartCFrame(Player.Character.HumanoidRootPart.CFrame)
			Spear:SetPrimaryPartCFrame(CFrame.new(Spear.PrimaryPart.CFrame.p, Pos.p) * CFrame.Angles(0,math.rad(270),0))
			SpearTween:Play()
			SpearTween.Completed:Wait()
			SpearTween:Cancel()
			Spear:SetPrimaryPartCFrame(CFrame.new(Spear.PrimaryPart.CFrame.p, Pos.p) * CFrame.Angles(0,math.rad(270),0) * CFrame.new(-(Spear.PrimaryPart.CFrame.p - Pos.p).magnitude + 1.5,0,0))]]
		end
	end)
	
	BoostEffect.OnServerEvent:connect(function(Player)
		if Player.Character:FindFirstChild('GasPiece') then
			Player.Character.GasPiece.GasPart.ParticleEmitter.Size = NumberSequence.new(1)
			Player.Character.GasPiece.GasPart.ParticleEmitter.LockedToPart = false
			Player.Character.GasPiece.GasPart.Gas.Enabled = true
			Player.Character.GasPiece.GasPart.GasSound.Volume = 0.35
			Player.Character.GasPiece.GasPart.GasSound.PlaybackSpeed = 2
		elseif Player.Character:FindFirstChild('UpperTorsoAP') then
			Player.Character.UpperTorsoAP.GasPiece.GasPart.ParticleEmitter.Size = NumberSequence.new(1)
			Player.Character.UpperTorsoAP.GasPiece.GasPart.ParticleEmitter.LockedToPart = false
			Player.Character.UpperTorsoAP.GasPiece.GasPart.Gas.Enabled = true
			Player.Character.UpperTorsoAP.GasPiece.GasPart.GasSound.Volume = 0.35
			Player.Character.UpperTorsoAP.GasPiece.GasPart.GasSound.PlaybackSpeed = 2
		end
	end)
	
	BoostEffectStop.OnServerEvent:connect(function(Player)
		if Player.Character:FindFirstChild('GasPiece') then
			Player.Character.GasPiece.GasPart.ParticleEmitter:Clear()
			Player.Character.GasPiece.GasPart.ParticleEmitter.Size = NumberSequence.new(0.4)
			Player.Character.GasPiece.GasPart.ParticleEmitter.LockedToPart = true
			Player.Character.GasPiece.GasPart.Gas.Enabled = false
			Player.Character.GasPiece.GasPart.GasSound.Volume = 0.1
			Player.Character.GasPiece.GasPart.GasSound.PlaybackSpeed = 2.5
		elseif Player.Character:FindFirstChild('UpperTorsoAP') then
			Player.Character.UpperTorsoAP.GasPiece.GasPart.ParticleEmitter:Clear()
			Player.Character.UpperTorsoAP.GasPiece.GasPart.ParticleEmitter.Size = NumberSequence.new(0.4)
			Player.Character.UpperTorsoAP.GasPiece.GasPart.ParticleEmitter.LockedToPart = true
			Player.Character.UpperTorsoAP.GasPiece.GasPart.Gas.Enabled = false
			Player.Character.UpperTorsoAP.GasPiece.GasPart.GasSound.Volume = 0.1
			Player.Character.UpperTorsoAP.GasPiece.GasPart.GasSound.PlaybackSpeed = 2.5
		end
	end)
	
	StopGas.OnServerEvent:connect(function(Player)
		if Player.Character:FindFirstChild('GasPiece') then
			Player.Character.GasPiece.GasPart.Gas.Enabled = false
			Player.Character.GasPiece.GasPart.ParticleEmitter.Enabled = false
		elseif Player.Character:FindFirstChild('UpperTorsoAP') then
			Player.Character.UpperTorsoAP.GasPiece.GasPart.Gas.Enabled = false
			Player.Character.UpperTorsoAP.GasPiece.GasPart.ParticleEmitter.Enabled = false
		end
	end)
	
	ServerGrappleDestroy.OnServerEvent:connect(function(Player, Hook, Key)
		if Hook ~= nil and Hook.Parent == GrappleFolder then
			Hook:Destroy()
		end
		if Key ~= nil then
			if workspace:FindFirstChild("GrappleFolder") then
				for num,SERVERWIRE in ipairs(workspace:FindFirstChild("GrappleFolder"):GetChildren()) do
					if SERVERWIRE.Name == "SERVERWIRE"..Player.Name..Key then
						SERVERWIRE:Destroy()
					end
				end
			end
		end
	end)
	
	local function titanSlam(slam, size)
		local function tweenBall(Part)
			if Part.ClassName == 'MeshPart' then
				Part.CFrame = Part.CFrame * CFrame.Angles(math.rad(1,360), math.rad(1,360), math.rad(1,360))
				local CircleInfo = TweenInfo.new(3, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)
				local Tween = TweenService:Create(Part, CircleInfo, {['Size'] = Vector3.new(size * 7.2, size * 7.2, 0.5), ['Transparency'] = 1})
				Tween:Play()
			elseif Part.ClassName == 'Part' then
				Part.CFrame = Part.CFrame * CFrame.Angles(math.rad(1,360), math.rad(1,360), math.rad(1,360))
				local CircleInfo = TweenInfo.new(3, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)
				local Tween = TweenService:Create(Part, CircleInfo, {['Size'] = Vector3.new(size * 5, size * 5, size * 5), ['Transparency'] = 1})
				Tween:Play()	
			end
		end
		
		
		for num,Part in ipairs(slam:GetChildren()) do
			if Part:IsA('BasePart') then
				tweenBall(Part)
			end
		end
		wait(0.4)
		for num,Player in ipairs(game.Players:GetPlayers()) do
			pcall(function()
				if (Player.Character.HumanoidRootPart.Position - slam.PrimaryPart.Position).magnitude / 2 < math.abs(slam.PrimaryPart.Size.X) then
					Player.Character.Humanoid:TakeDamage(math.random(30,40))
					Player.Character.Humanoid.PlatformStand = true
					wait(0.1)
					Player.Character.Humanoid.PlatformStand = false
				end
			end)
		end
		
		slam.PrimaryPart.Sound:Play()
		wait(slam.PrimaryPart.Sound.TimeLength)
		slam:Destroy()
	end
	
	local function tweenBall(Part)
		if Part.ClassName == 'MeshPart' then
			Part.CFrame = Part.CFrame * CFrame.Angles(math.rad(1,360), math.rad(1,360), math.rad(1,360))
			local CircleInfo = TweenInfo.new(1, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)
			local Tween = TweenService:Create(Part, CircleInfo, {['Size'] = Vector3.new(25.2, 25.2, 0.5), ['Transparency'] = 1})
			Tween:Play()
			spawn(function()
				wait(1)
				Part:Destroy()
			end)
		elseif Part.ClassName == 'Part' then
			Part.CFrame = Part.CFrame * CFrame.Angles(math.rad(1,360), math.rad(1,360), math.rad(1,360))
			local CircleInfo = TweenInfo.new(1, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)
			local Tween = TweenService:Create(Part, CircleInfo, {['Size'] = Vector3.new(20.2, 20.2, 20.2), ['Transparency'] = 1})
			Tween:Play()
			spawn(function()
				wait(1)
				Part:Destroy()
			end)
		end
	end
	local function checkBlades(Player)
		if Player.Character.BladeDurability.Value <= 0 then 
			for num, Hook in ipairs(Player.Character:GetChildren()) do
				if Hook.Name == "Blade" then
					if Player.Character:FindFirstChild('BladeDurability') then
						Player.Character.BladeDurability:Destroy()
					end
					Hook.Weld:Destroy()
					Debris:AddItem(Hook, 3)
					Hook.CanCollide = true
					Hook.Name = "BROKENBLADE"
				end
			end
		end
	end
	
	local function titanBlast(Part)
		local TitanBlast = game.ServerStorage.AOTObjects.TitanBlast:Clone()
		Debris:AddItem(TitanBlast, 5)
		TitanBlast.Parent = game.Workspace
		TitanBlast:SetPrimaryPartCFrame(Part.CFrame * CFrame.new(0,0,5))
		for num,Part in ipairs(TitanBlast:GetChildren()) do
			if Part:IsA('BasePart') then
				tweenBall(Part)
			end
		end
		TitanBlast.PrimaryPart.Sound:Play()
	end

	SlashEnemy.OnServerEvent:connect(function(Player, Player2)
		if (Player.Character.HumanoidRootPart.Position - Player2.HumanoidRootPart.Position).magnitude < 7 and game.Players:GetPlayerFromCharacter(Player2).TeamColor == game.Teams.Rogue.TeamColor then
			Player2.Humanoid.Health = Player2.Humanoid.Health - math.random(50,65)
			titanBlast(Player2.HumanoidRootPart)
		end
	end)
	
	KillTitan.OnServerEvent:connect(function(Player, Part)
		if Part:FindFirstAncestor('Titan') and Part:FindFirstAncestor('Titan'):FindFirstChild('Humanoid') and Part.Name == 'Nape' and (Player.Character.HumanoidRootPart.CFrame.p - Part.CFrame.p).magnitude < 30 and Player.Character.BladeDurability.Value > 0 then
			Player.Character.BladeDurability.Value = Player.Character.BladeDurability.Value - 0.5
			checkBlades(Player)
			local Monster = Part:FindFirstAncestor('Titan')
			if Monster.Parent.Name == 'TitanFolder' then
				Monster:FindFirstChild("Humanoid").Health = Monster:FindFirstChild("Humanoid").Health - _G[Player.Name]['BladeDamage']
				if Monster:FindFirstChild("Humanoid").Health <= 0 then
					Monster.HumanoidRootPart.Stomping:Stop()
				end
				titanBlast(Part)
				if Monster:FindFirstChild("Humanoid").Health <= 0 then
					Player.EXP.Value = Player.EXP.Value + math.random(80, 150)
					_G[Player.Name]['TitanKills'] = _G[Player.Name]['TitanKills'] + 1
					if Player:FindFirstChild('TitanKills') then
						Player.TitanKills.Value = _G[Player.Name]['TitanKills']
					end
					local function weldClear(Part)
						for num,HandWeld in ipairs(Part:GetChildren()) do
							if HandWeld.Name == 'GrabWeld' then
								HandWeld:Destroy()
							end
						end
					end
					weldClear(Monster.RightHand)
					weldClear(Monster.LeftHand)
					weldClear(Monster.LeftLowerArm)
					weldClear(Monster.RightLowerArm)
					if Monster.GrabPlayer.Value ~= nil and Monster.GrabPlayer.Value:FindFirstAncestor('Pedestrians') == nil then
						Monster.GrabPlayer.Value.Humanoid.WalkSpeed = 16
						Monster.GrabPlayer.Value.Grabbed.Value = false
						Monster.GrabPlayer.Value = nil
					end
					for num,Motor6D in ipairs(Monster:GetDescendants()) do
						if Motor6D:IsA('BasePart') and Motor6D.Name ~= 'Nape' and string.find(Motor6D.Name, 'WeakKnee') == nil then
							Motor6D.CanCollide = true
							Motor6D.Anchored = false
						end
						if Motor6D.ClassName == 'Motor6D' and Motor6D.Name ~= 'Neck' and string.find(Motor6D.Name, 'Wrist') == nil and string.find(Motor6D.Name, 'Ankle') == nil then
							local BallSocket = Instance.new('BallSocketConstraint', Motor6D.Parent)
							local motoName = Motor6D.Name
							local Attachment0 = Motor6D.Parent:FindFirstChild(motoName .. 'Attachment') or Motor6D.Parent:FindFirstChild(motoName .. 'RigAttachment')
							local Attachment1 = Motor6D.Part0:FindFirstChild(motoName .. 'Attachment') or Motor6D.Part0:FindFirstChild(motoName .. 'RigAttachment')
							if Attachment0 and Attachment1 then
								BallSocket.Attachment0 = Attachment0
								BallSocket.Attachment1 = Attachment1
								Motor6D:Destroy()
							end
							--Monster:SetPrimaryPartCFrame(Monster.PrimaryPart.CFrame * CFrame.Angles(math.rad(45),0,0))
						end
					end
					local oldPart = Monster
					Debris:AddItem(Monster, 15)
					Part:Destroy()
					oldPart.HumanoidRootPart:Destroy()
					oldPart.PrimaryPart = oldPart.Head
					if oldPart.Head:FindFirstChild('TitanHealthUI') then
						oldPart.Head.TitanHealthUI:Destroy()
					end
					oldPart.LWKHold:Destroy()
					oldPart.RWKHold:Destroy()
					oldPart.EyesHolder:Destroy()
					wait(5)
					for num,Steam in ipairs(oldPart:GetDescendants()) do
						if Steam.Name == 'Steam' and Steam.ClassName == 'ParticleEmitter' then
							Steam.Enabled = true
						end
					end
					wait(5)
					for num,Part in ipairs(oldPart:GetDescendants()) do
						if Part:IsA('BasePart') then
							Part.Color = Color3.fromRGB(0,0,0)
						end
					end
					wait(2)
					for num,Part in ipairs(oldPart:GetDescendants()) do
						if Part:IsA('MeshPart') and SkeletonMeshes[Part.Name] then
							Part.Transparency = 1
							local ClonePart = Instance.new('Part', Part.Parent)
							ClonePart.CanCollide = false
							ClonePart.Size = Part.Size
							ClonePart.CFrame = Part.CFrame
							ClonePart.Material = Part.Material
							ClonePart.Color = Part.Color
							
							local Weld = Instance.new('ManualWeld', Part)
							Weld.Part0 = ClonePart
							Weld.Part1 = Part
							Weld.C0 = CFrame.new(0,0,0)
							Weld.C1 = CFrame.new(0,0,0)
							
							local Mesh = Instance.new('SpecialMesh', ClonePart)
							Mesh.MeshId = SkeletonMeshes[Part.Name]
							Mesh.Scale = Part.Size
						elseif Part:IsA('Decal') or Part.Name == 'Handle' then
 							Part:Destroy()
						end
					end
					Monster.Head.Mesh.MeshId = game.ServerStorage.AOTObjects.HeadSkeletonMesh.MeshId
				end
			end
		elseif Part:FindFirstAncestor('Titan') and Part:FindFirstAncestor('Titan'):FindFirstChild('Humanoid') and (Part.Name == 'RightWeakKnee' or Part.Name == 'LeftWeakKnee') and Player.Character.BladeDurability.Value > 0 and Part:FindFirstAncestor('Titan').Occupied.Value == false then
			Player.Character.BladeDurability.Value = Player.Character.BladeDurability.Value - 0.5
			checkBlades(Player)
			local Monster = Part:FindFirstAncestor('Titan')
			--if Monster.Occupied.Value == false then
				Monster.Occupied.Value = true
				local function weldClear(Part)
					for num,HandWeld in ipairs(Part:GetChildren()) do
						if HandWeld.Name == 'GrabWeld' then
							HandWeld:Destroy()
						end
					end
				end
				weldClear(Monster.RightHand)
				weldClear(Monster.LeftHand)
				weldClear(Monster.LeftLowerArm)
				weldClear(Monster.RightLowerArm)
				if Monster.GrabPlayer.Value ~= nil then
					Monster.GrabPlayer.Value.Humanoid.WalkSpeed = 16
					Monster.GrabPlayer.Value.Grabbed.Value = false
					Monster.GrabPlayer.Value = nil
				end
				titanBlast(Part)
				Monster.HumanoidRootPart.CanCollide = false
				local Falling = Monster.Humanoid:LoadAnimation(game.ReplicatedStorage.TitanAnimations.TitanFall)
				Falling:Play()
				Monster.HumanoidRootPart.Stomping:Stop()
				for num,Part in ipairs(Monster:GetChildren()) do
					if Part:IsA('BasePart') then
						Part.Velocity = Vector3.new(0,0,0)
					end
				end
				wait(Falling.Length)
				Monster.HumanoidRootPart.Anchored = true
				Falling:Stop()
				local Falling = Monster.Humanoid:LoadAnimation(game.ReplicatedStorage.TitanAnimations.TitanGrounded)
				Falling:Play()
				for num,Part in ipairs(Monster:GetChildren()) do
					if Part:IsA('BasePart') then
						Part.Velocity = Vector3.new(0,0,0)
					end
				end
				wait(15)
				Monster.HumanoidRootPart.CanCollide = true
				Falling:Stop()
				Monster.HumanoidRootPart.Anchored = false
				Monster.Occupied.Value = false
				Monster.HumanoidRootPart.Stomping:Play()
			--end
		elseif Part:FindFirstAncestor('Titan') and Part:FindFirstAncestor('Titan'):FindFirstChild('Humanoid') and (Part.Name == 'Eyes') and Player.Character.BladeDurability.Value > 0 and Part:FindFirstAncestor('Titan').Occupied.Value == false  then
			Player.Character.BladeDurability.Value = Player.Character.BladeDurability.Value - 0.5
			checkBlades(Player)
			local Monster = Part:FindFirstAncestor('Titan')
			if Monster.Occupied.Value == false then
				Monster.Occupied.Value = true
				titanBlast(Part)
				local EyeAttack = Monster.Humanoid:LoadAnimation(game.ReplicatedStorage.TitanAnimations.TitanEyeAttack)
				EyeAttack:Play()
				Monster.HumanoidRootPart.Stomping:Stop()
				wait(81/24)
				if Monster.Humanoid.Health > 0 then
					local TitanSlam = game.ServerStorage.AOTObjects.TitanSlam:Clone()
					TitanSlam.Parent = EffectsFolder
					TitanSlam:SetPrimaryPartCFrame(Monster.LeftHand.CFrame)
					spawn(function()
						 titanSlam(TitanSlam, 10)
					end)
				end
				wait(17/24)
				if Monster.Humanoid.Health > 0 then
					local TitanSlam = game.ServerStorage.AOTObjects.TitanSlam:Clone()
					TitanSlam.Parent = EffectsFolder
					TitanSlam:SetPrimaryPartCFrame(Monster.RightHand.CFrame)
					spawn(function()
						 titanSlam(TitanSlam, 10)
					end)
				end
				wait(EyeAttack.Length - (98/24))
				print('Setting occupied to false')
				Monster.Occupied.Value = false
				Monster.HumanoidRootPart.Stomping:Play()
			end
		end
	end)
	
	ReloadBlades.OnServerEvent:connect(function(Player, Anim)
		--!! CHANGE 8 TO PLAYER DATASTORE BLADES LATER
			
			local WaitTime = 0
			local RBlades = true
			for num, Hook in ipairs(Player.Character:GetChildren()) do
				if Hook.Name == "Blade" then
					if Player.Character:FindFirstChild('BladeDurability') then
						Player.Character.BladeDurability:Destroy()
					end
					WaitTime = 1
					Hook.Weld:Destroy()
					Debris:AddItem(Hook, WaitTime)
					Hook.CanCollide = true
					Hook.Name = "BROKENBLADE"
					RBlades = false
				end
			end
			if RBlades == true then
				if Player.Character.BladeSupply.Value >= 2 and Player.Character.BladeSupply.Value > 0 then
					Player.Character.BladeSupply.Value = Player.Character.BladeSupply.Value - 2
					Player.Character.Humanoid:LoadAnimation(Anim):Play()
					wait(0.1430)
					local oldBlade = Player.Character.TorsoSec.LBladeHold:FindFirstChild('Blade')
					oldBlade.Name = 'SPENT'
					oldBlade.Transparency = 1
					local oldBlade = Player.Character.TorsoSec.RBladeHold:FindFirstChild('Blade')
					oldBlade.Name = 'SPENT'
					oldBlade.Transparency = 1
					if Player.Character:FindFirstChild('BladeDurability') then
						Player.Character.BladeDurability:Destroy()
					end
					local BladeDurability = Instance.new('NumberValue')
					BladeDurability.Name = 'BladeDurability'
					BladeDurability.Value = _G[Player.Name]['BladeStrength']
					BladeDurability.Parent = Player.Character
					-- SET VALUE TO SAVED BLADE DURABILITY LATER
					for num, Hook in ipairs(Player.Character:GetChildren()) do
						if (Hook.Name == "LArm" or Hook.Name == "RArm") and RBlades == true then
							local BladeClone = game.ServerStorage.AOTObjects.ManeuverGearR15.Blade:Clone()
							BladeClone.Parent = Player.Character
							local Weld = Instance.new("Weld", BladeClone)
							Weld.Part0 = BladeClone
							Weld.Part1 = Hook.MeshPart
							Weld.C0 = CFrame.new(0, 0, 0) * CFrame.Angles(-math.rad(41.5),math.rad(180), math.rad(180)) * CFrame.new(0,0,-2.3)
						end
					end
				end
			end
	end)
	
	ServerGrapple.OnServerEvent:connect(function(Player, Hook, Position, Part)
		if workspace:FindFirstChild("GrappleFolder") then
			for num,SERVERWIRE in ipairs(workspace:FindFirstChild("GrappleFolder"):GetChildren()) do
				if SERVERWIRE.Name == "SERVERWIRE"..Player.Name..'Q' or SERVERWIRE.Name == "SERVERWIRE"..Player.Name..'E' then
					SERVERWIRE:Destroy()
				end
			end
		end
		local HookQ = Instance.new("Part", GrappleFolder)
		HookQ.Shape = "Cylinder"
		HookQ.BrickColor = BrickColor.Black()
		-- GAS EFFECT
		--Player.Character.GasPiece.GasPart.Gas.Enabled = true
		if Player.Character:FindFirstChild('GasPiece') then
			Player.Character.GasPiece.GasPart.ParticleEmitter.Enabled = true
		elseif Player.Character:FindFirstChild('UpperTorsoAP') then
			Player.Character.UpperTorsoAP.GasPiece.GasPart.ParticleEmitter.Enabled = true
		end
		-- GAS EFFECT
		HookQ.Size = Vector3.new(0.05, 0.05, 0.05)
		HookQ.Parent = GrappleFolder
		if Hook.Name == "LeftHook" then
			HookQ.Name = "SERVERWIRE"..Player.Name.."Q"
		elseif Hook.Name == "RightHook" then
			HookQ.Name = "SERVERWIRE"..Player.Name.."E"
		end
		HookQ.Anchored = true
		HookQ.CanCollide = false
		ServerGrapple:FireAllClients(Hook, Position, HookQ, Part)
	end)