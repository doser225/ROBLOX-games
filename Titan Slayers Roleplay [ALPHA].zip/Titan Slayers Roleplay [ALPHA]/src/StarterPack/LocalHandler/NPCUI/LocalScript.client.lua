local TextBox = script.Parent.Frame.BodyText
local NPC = script.Parent.NPC.Value
local Skip = false
local Player = game.Players.LocalPlayer
script.Parent.Frame.NPCName.TextLabel.Text = NPC.NPCName.Value

script.Parent.Frame.Skip.MouseButton1Click:Connect(function()
	Skip = true
end)

for number = 1,#NPC.Dialogue:GetChildren() do
	Skip = false
	for num = 1,string.len(NPC.Dialogue[number].Value) do
		if Skip == false then
			if NPC.Dialogue[number].ClassName == 'StringValue' then
				if NPC.Dialogue[number].TBT.Value ~= nil or NPC.Dialogue[number].TBT.Value ~= 0 then
					wait(NPC.Dialogue[number].TBT.Value)
				else
					wait()
				end
				if string.sub(NPC.Dialogue[number].Value, num, num) ~= ' ' then
					script.Parent.Click:Play()
				end
				TextBox.Text = string.sub(NPC.Dialogue[number].Value, 1, num)
			end
		else
			if NPC.Dialogue[number].ClassName == 'StringValue' then
				TextBox.Text = NPC.Dialogue[number].Value
			end
			break
		end
	end
	wait(1)
end

for num,UI in ipairs(Player.PlayerGui:GetChildren()) do
	if UI.Name == "NPCUI" then
		UI:Destroy()
	end
end

if NPC.Dialogue.Parent:FindFirstChild('SellAll') then
	NPC.Dialogue.Parent.SellAll:Clone().Parent = Player.PlayerGui
	wait(10)
elseif NPC.Dialogue.Parent:FindFirstChild('shopui') then
	NPC.Dialogue.Parent.shopui:Clone().Parent = Player.PlayerGui
elseif NPC.Dialogue.Parent:FindFirstChild('Horse') then
	NPC.Dialogue.Parent.Horse:Clone().Parent = Player.PlayerGui
else
	wait(1)
end

for num,UI in ipairs(Player.PlayerGui:GetChildren()) do
	if UI.Name == "NPCUI" or UI.Name == "SellAll" then
		UI:Destroy()
	end
end
game.Workspace.Camera.CameraType = Enum.CameraType.Custom