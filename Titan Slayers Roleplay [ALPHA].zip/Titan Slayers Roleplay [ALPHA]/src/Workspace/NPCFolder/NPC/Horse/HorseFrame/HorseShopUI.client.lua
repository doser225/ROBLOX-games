local Player = game.Players.LocalPlayer
local MAINFE = game.ReplicatedStorage:WaitForChild('MAINFE')
local HorsePurchase = MAINFE:WaitForChild('HorsePurchase')
local Horses = game.ReplicatedStorage:WaitForChild('Horses'):GetChildren()
local TotalHorses = #Horses
local Index = 1
game.Workspace:WaitForChild('HorseSelectPart')

local CurrentHorse = nil

game.Workspace.CurrentCamera.CameraType = Enum.CameraType.Scriptable
game.Workspace.CurrentCamera.CFrame = game.Workspace.HorseSelectPart.CFrame * CFrame.new(-2,7,12) * CFrame.Angles(-math.rad(20),-math.rad(15),0)

local function loadHorse()
	if CurrentHorse ~= nil then
		CurrentHorse:Destroy()
	end
	game.Workspace.CurrentCamera.CameraType = Enum.CameraType.Scriptable
	game.Workspace.CurrentCamera.CFrame = game.Workspace.HorseSelectPart.CFrame * CFrame.new(-2,7,12) * CFrame.Angles(-math.rad(20),-math.rad(15),0)
	CurrentHorse = Horses[Index]:Clone()
	CurrentHorse.Parent = game.Workspace
	CurrentHorse:SetPrimaryPartCFrame(game.Workspace.HorseSelectPart.CFrame * CFrame.new(0,2,0) * CFrame.Angles(0,math.rad(180),0))
	script.Parent.HorseName.Text = CurrentHorse.Name
	script.Parent.HowMuchGold.Gold.Text = CurrentHorse.Cost.Value
end

local Confirmation = script.Parent:WaitForChild('ConfirmPurchase')
Confirmation.Parent = nil

loadHorse()

script.Parent.PurchaseGold.MouseButton1Click:Connect(function()
	if CurrentHorse ~= nil then
		for num,Gui in ipairs(Player.PlayerGui:GetChildren()) do
			if Gui.Name == 'ConfirmPurchase' then
				Gui:Destroy()
			end
		end
		Confirmation.Parent = script
		local Clone = Confirmation:Clone()
		Confirmation.Parent = nil
		Clone.brokepeople.SellBackground.text1.Text = "Purchase horse: " .. CurrentHorse.Cost.Value .. "?"
		Clone.brokepeople.LocalScript.HorseName.Value = CurrentHorse.Name
		Clone.Parent = Player.PlayerGui
	end
end)

script.Parent.ArrowLeft.MouseButton1Click:connect(function()
	if Index > 1 then
		Index = Index - 1
		loadHorse()
	end
end)

script.Parent.ArrowRight.MouseButton1Click:connect(function()
	if Index < TotalHorses then
		Index = Index + 1
		loadHorse()
	end
end)
script.Parent.CloseDatThing.MouseButton1Click:Connect(function()
	if CurrentHorse then
		CurrentHorse:Destroy()
	end
	game.Workspace.CurrentCamera.CameraType = Enum.CameraType.Custom
	game.Workspace.CurrentCamera.CameraSubject = game.Players.LocalPlayer.Character.Humanoid
	script.Parent.Parent:Destroy()
end)