script.Parent.Died:Connect(function()
	wait(5)
	script.Parent.Parent:Destroy()
end)