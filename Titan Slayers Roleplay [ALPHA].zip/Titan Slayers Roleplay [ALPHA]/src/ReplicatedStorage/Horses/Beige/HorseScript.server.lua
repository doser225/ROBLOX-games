script.Parent.Seat:GetPropertyChangedSignal('Occupant'):connect(function()
	print(script.Parent.Seat.Occupant)
	if script.Parent.Seat.Occupant ~= nil then
		local Player = game.Players:GetPlayerFromCharacter(script.Parent.Seat.Occupant.Parent)
		local HC = game.ServerStorage.HorseController:Clone()
		HC.Parent = Player.Backpack
		HC.Disabled = false
	end	
end)